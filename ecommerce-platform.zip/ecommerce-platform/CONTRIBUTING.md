# Contributing

## Branching

- `main` — protected, deployable to staging.
- `feat/*` — short-lived feature branches.
- Use Conventional Commits (`feat:`, `fix:`, `chore:`, `docs:`, `test:`).

## Pull requests

Every PR must:

1. Pass `make lint` and `make tf-validate`.
2. Pass `tfsec` and `checkov` (run automatically in CI).
3. Include an Infracost summary comment if Terraform changes are involved.
4. Have at least one approving review.

## Local development loop

```bash
make kind-up
make build-images
make deploy-local
```

To tear down: `make undeploy-local && make kind-down`.
