# monitoring

Configurations for the in-cluster observability stack (kube-prometheus-stack +
Loki). Apply via Helm:

```bash
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo add grafana https://grafana.github.io/helm-charts
helm repo update

helm upgrade --install monitoring prometheus-community/kube-prometheus-stack \
  -n observability --create-namespace \
  -f monitoring/prometheus/values.yaml

helm upgrade --install loki grafana/loki-stack \
  -n observability \
  -f monitoring/loki/values.yaml
```
