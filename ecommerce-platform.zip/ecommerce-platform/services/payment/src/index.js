const express = require("express");
const pino = require("pino");
const pinoHttp = require("pino-http");
const client = require("prom-client");
const crypto = require("node:crypto");

const log = pino({ level: process.env.LOG_LEVEL || "info" });
const app = express();
app.use(express.json());
app.use(pinoHttp({ logger: log }));

const register = new client.Registry();
client.collectDefaultMetrics({ register });

const httpDuration = new client.Histogram({
  name: "http_request_duration_seconds",
  help: "HTTP request duration in seconds",
  labelNames: ["method", "route", "status"],
  buckets: [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10],
});
const paymentsTotal = new client.Counter({
  name: "payments_total",
  help: "Total number of payments processed",
  labelNames: ["status"],
});
register.registerMetric(httpDuration);
register.registerMetric(paymentsTotal);

app.use((req, res, next) => {
  const end = httpDuration.startTimer();
  res.on("finish", () => {
    end({ method: req.method, route: req.route?.path || req.path, status: res.statusCode });
  });
  next();
});

const FAILURE_RATE = parseFloat(process.env.PAYMENT_FAILURE_RATE || "0.02");

app.get("/healthz", (_req, res) => res.json({ status: "ok" }));
app.get("/readyz",  (_req, res) => res.json({ status: "ready" }));

app.post("/payments", (req, res) => {
  const { orderId, amount, method } = req.body || {};
  if (!orderId || !(amount > 0) || !method) {
    paymentsTotal.inc({ status: "invalid" });
    return res.status(400).json({ error: "invalid_input" });
  }
  const succeeds = Math.random() >= FAILURE_RATE;
  if (!succeeds) {
    paymentsTotal.inc({ status: "failed" });
    return res.status(402).json({ error: "payment_declined" });
  }
  paymentsTotal.inc({ status: "succeeded" });
  res.status(201).json({
    paymentId: crypto.randomUUID(),
    orderId,
    amount,
    method,
    status: "SUCCESS",
    processedAt: new Date().toISOString(),
  });
});

app.get("/metrics", async (_req, res) => {
  res.set("Content-Type", register.contentType);
  res.end(await register.metrics());
});

const PORT = parseInt(process.env.PORT || "8080", 10);
app.listen(PORT, () => log.info({ port: PORT }, "payment service listening"));
