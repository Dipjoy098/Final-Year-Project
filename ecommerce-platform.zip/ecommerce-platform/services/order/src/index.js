const express = require("express");
const pino = require("pino");
const pinoHttp = require("pino-http");
const client = require("prom-client");
const crypto = require("node:crypto");

const log = pino({ level: process.env.LOG_LEVEL || "info" });
const app = express();
app.use(express.json());
app.use(pinoHttp({ logger: log }));

const register = new client.Registry();
client.collectDefaultMetrics({ register });

const httpDuration = new client.Histogram({
  name: "http_request_duration_seconds",
  help: "HTTP request duration in seconds",
  labelNames: ["method", "route", "status"],
  buckets: [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10],
});
const ordersCreated = new client.Counter({
  name: "orders_created_total",
  help: "Total number of orders created",
  labelNames: ["status"],
});
register.registerMetric(httpDuration);
register.registerMetric(ordersCreated);

app.use((req, res, next) => {
  const end = httpDuration.startTimer();
  res.on("finish", () => {
    end({ method: req.method, route: req.route?.path || req.path, status: res.statusCode });
  });
  next();
});

const orders = new Map();

app.get("/healthz", (_req, res) => res.json({ status: "ok" }));
app.get("/readyz",  (_req, res) => res.json({ status: "ready" }));

app.post("/orders", (req, res) => {
  const { userId, items, total } = req.body;
  if (!userId || !Array.isArray(items) || items.length === 0) {
    ordersCreated.inc({ status: "rejected" });
    return res.status(400).json({ error: "invalid_input" });
  }
  const id = crypto.randomUUID();
  const order = { id, userId, items, total, status: "PENDING", createdAt: new Date().toISOString() };
  orders.set(id, order);
  ordersCreated.inc({ status: "accepted" });
  res.status(201).json(order);
});

app.get("/orders/:id", (req, res) => {
  const order = orders.get(req.params.id);
  if (!order) return res.status(404).json({ error: "not_found" });
  res.json(order);
});

app.post("/orders/:id/confirm", (req, res) => {
  const order = orders.get(req.params.id);
  if (!order) return res.status(404).json({ error: "not_found" });
  order.status = "CONFIRMED";
  res.json(order);
});

app.get("/metrics", async (_req, res) => {
  res.set("Content-Type", register.contentType);
  res.end(await register.metrics());
});

const PORT = parseInt(process.env.PORT || "8080", 10);
app.listen(PORT, () => log.info({ port: PORT }, "order service listening"));
