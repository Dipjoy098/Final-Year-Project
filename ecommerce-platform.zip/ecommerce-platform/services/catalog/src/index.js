const express = require("express");
const pino = require("pino");
const pinoHttp = require("pino-http");
const client = require("prom-client");

const log = pino({ level: process.env.LOG_LEVEL || "info" });
const app = express();
app.use(express.json());
app.use(pinoHttp({ logger: log }));

const register = new client.Registry();
client.collectDefaultMetrics({ register });

const httpDuration = new client.Histogram({
  name: "http_request_duration_seconds",
  help: "HTTP request duration in seconds",
  labelNames: ["method", "route", "status"],
  buckets: [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10],
});
register.registerMetric(httpDuration);

app.use((req, res, next) => {
  const end = httpDuration.startTimer();
  res.on("finish", () => {
    end({ method: req.method, route: req.route?.path || req.path, status: res.statusCode });
  });
  next();
});

// Food-delivery catalog. Extra fields (restaurant, veg, rating, eta, emoji,
// desc, bestseller) are additive — the API shape stays { products: [...] } so
// the cart / order / payment services are unaffected.
const products = [
  { id: "p-001", name: "Margherita Pizza",    price: 199, stock: 100, category: "pizza",         restaurant: "Napoli Kitchen",  veg: true,  rating: 4.3, eta: 30, emoji: "🍕", bestseller: true,  desc: "Wood-fired crust, San Marzano tomatoes, fresh basil." },
  { id: "p-002", name: "Double Cheese Burger", price: 179, stock: 90,  category: "burgers",        restaurant: "Burger Barn",     veg: false, rating: 4.5, eta: 25, emoji: "🍔", bestseller: true,  desc: "Two smashed patties, cheddar and house sauce." },
  { id: "p-003", name: "Chicken Biryani",      price: 249, stock: 120, category: "biryani",        restaurant: "Hyderabad House", veg: false, rating: 4.6, eta: 40, emoji: "🍛", bestseller: true,  desc: "Dum-cooked basmati, saffron and tender chicken." },
  { id: "p-004", name: "Masala Dosa",          price: 129, stock: 150, category: "south-indian",   restaurant: "Dosa Junction",   veg: true,  rating: 4.4, eta: 20, emoji: "🥘", bestseller: false, desc: "Crispy dosa, spiced potato and coconut chutney." },
  { id: "p-005", name: "Hakka Noodles",        price: 159, stock: 110, category: "chinese",        restaurant: "Wok & Roll",      veg: true,  rating: 4.1, eta: 25, emoji: "🍜", bestseller: false, desc: "Wok-tossed noodles with crunchy vegetables." },
  { id: "p-006", name: "Chocolate Brownie",    price: 99,  stock: 200, category: "desserts",       restaurant: "Sugar Rush",      veg: true,  rating: 4.7, eta: 15, emoji: "🍫", bestseller: true,  desc: "Fudgy brownie with a molten center." },
  { id: "p-007", name: "Cold Coffee",          price: 119, stock: 180, category: "beverages",      restaurant: "Brew Bar",        veg: true,  rating: 4.2, eta: 15, emoji: "🧋", bestseller: false, desc: "Chilled, frothy, double-shot cold coffee." },
  { id: "p-008", name: "Paneer Tikka",         price: 219, stock: 80,  category: "north-indian",   restaurant: "Tandoor Tales",   veg: true,  rating: 4.5, eta: 30, emoji: "🍢", bestseller: false, desc: "Charred paneer, capsicum and mint chutney." },
  { id: "p-009", name: "Veg Spring Rolls",     price: 109, stock: 130, category: "chinese",        restaurant: "Wok & Roll",      veg: true,  rating: 4.0, eta: 20, emoji: "🥟", bestseller: false, desc: "Crispy rolls stuffed with fresh vegetables." },
  { id: "p-010", name: "Butter Chicken",       price: 279, stock: 70,  category: "north-indian",   restaurant: "Tandoor Tales",   veg: false, rating: 4.6, eta: 35, emoji: "🍗", bestseller: true,  desc: "Creamy tomato gravy with tandoori chicken." },
  { id: "p-011", name: "Gulab Jamun",          price: 79,  stock: 220, category: "desserts",       restaurant: "Sugar Rush",      veg: true,  rating: 4.4, eta: 15, emoji: "🍩", bestseller: false, desc: "Warm syrup-soaked dumplings (2 pcs)." },
  { id: "p-012", name: "Mango Smoothie",       price: 139, stock: 160, category: "beverages",      restaurant: "Brew Bar",        veg: true,  rating: 4.3, eta: 15, emoji: "🥤", bestseller: false, desc: "Alphonso mango, yogurt and a touch of honey." },
];

app.get("/healthz", (_req, res) => res.json({ status: "ok" }));
app.get("/readyz",  (_req, res) => res.json({ status: "ready" }));

app.get("/products", (req, res) => {
  const { category } = req.query;
  const filtered = category ? products.filter(p => p.category === category) : products;
  res.json({ products: filtered });
});

app.get("/products/:id", (req, res) => {
  const product = products.find(p => p.id === req.params.id);
  if (!product) return res.status(404).json({ error: "not_found" });
  res.json(product);
});

app.get("/metrics", async (_req, res) => {
  res.set("Content-Type", register.contentType);
  res.end(await register.metrics());
});

const PORT = parseInt(process.env.PORT || "8080", 10);
app.listen(PORT, () => log.info({ port: PORT }, "catalog service listening"));
