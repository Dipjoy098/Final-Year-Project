const express = require("express");
const pino = require("pino");
const pinoHttp = require("pino-http");
const client = require("prom-client");

const log = pino({ level: process.env.LOG_LEVEL || "info" });
const app = express();
app.use(express.json());
app.use(pinoHttp({ logger: log }));

const register = new client.Registry();
client.collectDefaultMetrics({ register });

const httpDuration = new client.Histogram({
  name: "http_request_duration_seconds",
  help: "HTTP request duration in seconds",
  labelNames: ["method", "route", "status"],
  buckets: [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10],
});
register.registerMetric(httpDuration);

app.use((req, res, next) => {
  const end = httpDuration.startTimer();
  res.on("finish", () => {
    end({ method: req.method, route: req.route?.path || req.path, status: res.statusCode });
  });
  next();
});

const products = [
  { id: "p-001", name: "Cotton T-Shirt", price: 19.99, stock: 120, category: "apparel" },
  { id: "p-002", name: "Wireless Mouse", price: 24.5, stock: 80, category: "electronics" },
  { id: "p-003", name: "Coffee Mug", price: 9.0, stock: 300, category: "home" },
  { id: "p-004", name: "Yoga Mat", price: 29.99, stock: 50, category: "fitness" },
  { id: "p-005", name: "Stainless Bottle", price: 17.49, stock: 200, category: "home" },
];

app.get("/healthz", (_req, res) => res.json({ status: "ok" }));
app.get("/readyz",  (_req, res) => res.json({ status: "ready" }));

app.get("/products", (req, res) => {
  const { category } = req.query;
  const filtered = category ? products.filter(p => p.category === category) : products;
  res.json({ products: filtered });
});

app.get("/products/:id", (req, res) => {
  const product = products.find(p => p.id === req.params.id);
  if (!product) return res.status(404).json({ error: "not_found" });
  res.json(product);
});

app.get("/metrics", async (_req, res) => {
  res.set("Content-Type", register.contentType);
  res.end(await register.metrics());
});

const PORT = parseInt(process.env.PORT || "8080", 10);
app.listen(PORT, () => log.info({ port: PORT }, "catalog service listening"));
