// Smoke tests for the catalog service.
const test = require("node:test");
const assert = require("node:assert");

test("Node version is at least 20", () => {
  const major = parseInt(process.versions.node.split(".")[0], 10);
  assert.ok(major >= 20, `expected Node >= 20, got ${process.versions.node}`);
});

test("env defaults", () => {
  const port = parseInt(process.env.PORT || "8080", 10);
  assert.ok(port > 0 && port < 65536);
});
