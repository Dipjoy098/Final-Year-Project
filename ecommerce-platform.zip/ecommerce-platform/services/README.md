# services

Five microservices, each a tiny Express app exposing:

- `GET /healthz` — liveness
- `GET /readyz` — readiness
- `GET /metrics` — Prometheus metrics

| Service   | Purpose                                          |
| --------- | ------------------------------------------------ |
| frontend  | Storefront BFF, fans out to the rest.            |
| catalog   | In-memory product catalog.                       |
| cart      | Per-user cart, in-memory.                        |
| order     | Order state machine (PENDING → CONFIRMED).       |
| payment   | Mock payment authorization with configurable failure rate. |

These are intentionally minimal — the project's focus is the deployment
pipeline, not the business logic.
