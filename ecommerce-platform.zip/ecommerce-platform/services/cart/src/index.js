const express = require("express");
const pino = require("pino");
const pinoHttp = require("pino-http");
const client = require("prom-client");

const log = pino({ level: process.env.LOG_LEVEL || "info" });
const app = express();
app.use(express.json());
app.use(pinoHttp({ logger: log }));

const register = new client.Registry();
client.collectDefaultMetrics({ register });

const httpDuration = new client.Histogram({
  name: "http_request_duration_seconds",
  help: "HTTP request duration in seconds",
  labelNames: ["method", "route", "status"],
  buckets: [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10],
});
register.registerMetric(httpDuration);

app.use((req, res, next) => {
  const end = httpDuration.startTimer();
  res.on("finish", () => {
    end({ method: req.method, route: req.route?.path || req.path, status: res.statusCode });
  });
  next();
});

const carts = new Map();

app.get("/healthz", (_req, res) => res.json({ status: "ok" }));
app.get("/readyz",  (_req, res) => res.json({ status: "ready" }));

app.get("/cart/:userId", (req, res) => {
  const cart = carts.get(req.params.userId) || { userId: req.params.userId, items: [] };
  res.json(cart);
});

app.post("/cart/:userId/items", (req, res) => {
  const { productId, quantity } = req.body;
  if (!productId || !Number.isInteger(quantity) || quantity <= 0) {
    return res.status(400).json({ error: "invalid_input" });
  }
  const cart = carts.get(req.params.userId) || { userId: req.params.userId, items: [] };
  const existing = cart.items.find(i => i.productId === productId);
  if (existing) existing.quantity += quantity;
  else cart.items.push({ productId, quantity });
  carts.set(req.params.userId, cart);
  res.status(201).json(cart);
});

app.delete("/cart/:userId", (req, res) => {
  carts.delete(req.params.userId);
  res.status(204).end();
});

app.get("/metrics", async (_req, res) => {
  res.set("Content-Type", register.contentType);
  res.end(await register.metrics());
});

const PORT = parseInt(process.env.PORT || "8080", 10);
app.listen(PORT, () => log.info({ port: PORT }, "cart service listening"));
