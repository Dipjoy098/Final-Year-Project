const express = require("express");
const pino = require("pino");
const pinoHttp = require("pino-http");
const client = require("prom-client");

const log = pino({ level: process.env.LOG_LEVEL || "info" });
const app = express();
app.use(express.json());
app.use(pinoHttp({ logger: log }));

const CATALOG_URL = process.env.CATALOG_URL || "http://catalog:8080";
const CART_URL    = process.env.CART_URL    || "http://cart:8080";
const ORDER_URL   = process.env.ORDER_URL   || "http://order:8080";
const PAYMENT_URL = process.env.PAYMENT_URL || "http://payment:8080";

const register = new client.Registry();
client.collectDefaultMetrics({ register });
const httpDuration = new client.Histogram({
  name: "http_request_duration_seconds",
  help: "HTTP request duration in seconds",
  labelNames: ["method", "route", "status"],
  buckets: [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10],
});
register.registerMetric(httpDuration);

app.use((req, res, next) => {
  const end = httpDuration.startTimer();
  res.on("finish", () => {
    end({ method: req.method, route: req.route?.path || req.path, status: res.statusCode });
  });
  next();
});

const fetchJson = async (url, opts = {}) => {
  const res = await fetch(url, opts);
  if (!res.ok) throw new Error(`upstream ${res.status} from ${url}`);
  return res.json();
};

app.get("/healthz", (_req, res) => res.json({ status: "ok" }));
app.get("/readyz",  (_req, res) => res.json({ status: "ready" }));

app.get("/", (_req, res) => {
  res.type("html").send(`
    <!doctype html>
    <html><head><title>E-Commerce Platform</title>
      <style>body{font-family:system-ui,sans-serif;max-width:720px;margin:2rem auto;padding:0 1rem;}
      h1{color:#ee6c2a}a{color:#1a73e8}</style>
    </head><body>
      <h1>E-Commerce Platform</h1>
      <p>Reference deployment running on Kubernetes.</p>
      <ul>
        <li><a href="/api/products">/api/products</a> &mdash; catalog</li>
        <li><code>POST /api/cart/{user}/items</code> &mdash; add to cart</li>
        <li><code>POST /api/orders</code> &mdash; place order</li>
        <li><a href="/healthz">/healthz</a> &mdash; liveness</li>
        <li><a href="/metrics">/metrics</a> &mdash; Prometheus metrics</li>
      </ul>
    </body></html>`);
});

app.get("/api/products", async (_req, res) => {
  try {
    const data = await fetchJson(`${CATALOG_URL}/products`);
    res.json(data);
  } catch (err) {
    log.error({ err: err.message }, "catalog upstream failed");
    res.status(502).json({ error: "upstream_unavailable" });
  }
});

app.post("/api/cart/:userId/items", async (req, res) => {
  try {
    const r = await fetch(`${CART_URL}/cart/${req.params.userId}/items`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(req.body),
    });
    res.status(r.status).send(await r.text());
  } catch (err) {
    res.status(502).json({ error: "upstream_unavailable" });
  }
});

app.post("/api/orders", async (req, res) => {
  try {
    const order = await fetchJson(`${ORDER_URL}/orders`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(req.body),
    });
    const payment = await fetchJson(`${PAYMENT_URL}/payments`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ orderId: order.id, amount: req.body.total, method: "card" }),
    });
    await fetchJson(`${ORDER_URL}/orders/${order.id}/confirm`, { method: "POST" });
    res.status(201).json({ order, payment });
  } catch (err) {
    log.error({ err: err.message }, "checkout failed");
    res.status(502).json({ error: "checkout_failed" });
  }
});

app.get("/metrics", async (_req, res) => {
  res.set("Content-Type", register.contentType);
  res.end(await register.metrics());
});

const PORT = parseInt(process.env.PORT || "8080", 10);
app.listen(PORT, () => log.info({ port: PORT }, "frontend listening"));
