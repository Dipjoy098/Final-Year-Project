const express = require("express");
const pino = require("pino");
const pinoHttp = require("pino-http");
const client = require("prom-client");

const log = pino({ level: process.env.LOG_LEVEL || "info" });
const app = express();
app.use(express.json());
app.use(pinoHttp({ logger: log }));

const CATALOG_URL = process.env.CATALOG_URL || "http://catalog:8080";
const CART_URL    = process.env.CART_URL    || "http://cart:8080";
const ORDER_URL   = process.env.ORDER_URL   || "http://order:8080";
const PAYMENT_URL = process.env.PAYMENT_URL || "http://payment:8080";

const register = new client.Registry();
client.collectDefaultMetrics({ register });
const httpDuration = new client.Histogram({
  name: "http_request_duration_seconds",
  help: "HTTP request duration in seconds",
  labelNames: ["method", "route", "status"],
  buckets: [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10],
});
register.registerMetric(httpDuration);

app.use((req, res, next) => {
  const end = httpDuration.startTimer();
  res.on("finish", () => {
    end({ method: req.method, route: req.route?.path || req.path, status: res.statusCode });
  });
  next();
});

const fetchJson = async (url, opts = {}) => {
  const res = await fetch(url, opts);
  if (!res.ok) throw new Error(`upstream ${res.status} from ${url}`);
  return res.json();
};

app.get("/healthz", (_req, res) => res.json({ status: "ok" }));
app.get("/readyz",  (_req, res) => res.json({ status: "ready" }));

const STOREFRONT_HTML = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Nimbus — Store</title>
<style>
  :root{
    --bg:#0f1115; --panel:#171a21; --panel-2:#1e222c; --line:#2a2f3a;
    --text:#e7eaf0; --muted:#9aa3b2; --brand:#ff6b2c; --brand-2:#ffd166;
    --ok:#2ecc71; --danger:#ff5c5c; --radius:14px;
  }
  *{box-sizing:border-box}
  body{margin:0;font-family:'Inter',system-ui,-apple-system,Segoe UI,Roboto,sans-serif;
    background:linear-gradient(180deg,#0b0d11,#0f1115 40%);color:var(--text);min-height:100vh}
  a{color:inherit}
  header{position:sticky;top:0;z-index:20;backdrop-filter:blur(10px);
    background:rgba(15,17,21,.8);border-bottom:1px solid var(--line)}
  .bar{max-width:1100px;margin:0 auto;display:flex;align-items:center;gap:1rem;padding:.9rem 1.25rem}
  .logo{display:flex;align-items:center;gap:.55rem;font-weight:800;font-size:1.25rem;letter-spacing:-.02em}
  .logo .dot{width:22px;height:22px;border-radius:7px;
    background:linear-gradient(135deg,var(--brand),var(--brand-2));box-shadow:0 4px 14px rgba(255,107,44,.45)}
  .logo small{font-weight:500;color:var(--muted);font-size:.7rem;margin-left:.15rem}
  .spacer{flex:1}
  .cart-btn{position:relative;border:1px solid var(--line);background:var(--panel);
    color:var(--text);border-radius:999px;padding:.55rem .95rem;cursor:pointer;font-weight:600;font-size:.9rem}
  .cart-btn:hover{border-color:var(--brand)}
  .badge{position:absolute;top:-7px;right:-7px;min-width:20px;height:20px;border-radius:999px;
    background:var(--brand);color:#111;font-size:.72rem;font-weight:800;display:grid;place-items:center;padding:0 5px}
  .hero{max-width:1100px;margin:1.75rem auto .5rem;padding:0 1.25rem}
  .hero h1{font-size:2rem;margin:.2rem 0;letter-spacing:-.03em}
  .hero p{color:var(--muted);margin:.2rem 0 1rem}
  .filters{display:flex;flex-wrap:wrap;gap:.5rem;margin:.75rem 0 0}
  .chip{border:1px solid var(--line);background:var(--panel);color:var(--muted);
    border-radius:999px;padding:.4rem .85rem;cursor:pointer;font-size:.85rem;text-transform:capitalize}
  .chip.active{background:var(--brand);color:#111;border-color:var(--brand);font-weight:700}
  main{max-width:1100px;margin:1.25rem auto 4rem;padding:0 1.25rem}
  .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:1.1rem}
  .card{background:var(--panel);border:1px solid var(--line);border-radius:var(--radius);
    overflow:hidden;display:flex;flex-direction:column;transition:transform .15s,border-color .15s}
  .card:hover{transform:translateY(-3px);border-color:#3a4150}
  .thumb{height:150px;display:grid;place-items:center;font-size:3.2rem;
    background:radial-gradient(120% 120% at 30% 20%,#232936,#12151c)}
  .card .body{padding:.85rem .95rem 1rem;display:flex;flex-direction:column;gap:.35rem;flex:1}
  .card .cat{font-size:.7rem;text-transform:uppercase;letter-spacing:.08em;color:var(--muted)}
  .card h3{margin:0;font-size:1rem}
  .card .row{display:flex;align-items:center;justify-content:space-between;margin-top:auto;padding-top:.5rem}
  .price{font-weight:800;font-size:1.05rem}
  .stock{font-size:.72rem;color:var(--muted)}
  .add{border:0;border-radius:9px;background:var(--brand);color:#111;font-weight:700;
    padding:.5rem .8rem;cursor:pointer;font-size:.85rem}
  .add:hover{filter:brightness(1.08)}
  .add:disabled{background:#333;color:#777;cursor:not-allowed}
  /* cart drawer */
  .overlay{position:fixed;inset:0;background:rgba(0,0,0,.5);opacity:0;pointer-events:none;
    transition:opacity .2s;z-index:30}
  .overlay.open{opacity:1;pointer-events:auto}
  .drawer{position:fixed;top:0;right:0;height:100%;width:min(400px,92vw);z-index:40;
    background:var(--panel-2);border-left:1px solid var(--line);transform:translateX(100%);
    transition:transform .22s ease;display:flex;flex-direction:column}
  .drawer.open{transform:translateX(0)}
  .drawer header{position:static;background:none;border:0;padding:1.1rem 1.25rem;
    border-bottom:1px solid var(--line);display:flex;align-items:center}
  .drawer header h2{margin:0;font-size:1.15rem}
  .close{margin-left:auto;background:none;border:0;color:var(--muted);font-size:1.5rem;cursor:pointer;line-height:1}
  .items{flex:1;overflow:auto;padding:.5rem 1.25rem}
  .item{display:flex;gap:.75rem;align-items:center;padding:.7rem 0;border-bottom:1px solid var(--line)}
  .item .emoji{font-size:1.6rem}
  .item .grow{flex:1}
  .item .nm{font-size:.92rem}
  .item .mut{font-size:.76rem;color:var(--muted)}
  .qty{font-variant-numeric:tabular-nums;font-weight:700}
  .empty{color:var(--muted);text-align:center;padding:2.5rem 1rem}
  .foot{padding:1.1rem 1.25rem;border-top:1px solid var(--line)}
  .total{display:flex;justify-content:space-between;font-weight:800;font-size:1.15rem;margin-bottom:.8rem}
  .checkout{width:100%;border:0;border-radius:11px;background:linear-gradient(135deg,var(--brand),var(--brand-2));
    color:#111;font-weight:800;font-size:1rem;padding:.85rem;cursor:pointer}
  .checkout:disabled{opacity:.6;cursor:not-allowed}
  .toast{position:fixed;bottom:1.25rem;left:50%;transform:translateX(-50%) translateY(20px);
    background:var(--panel-2);border:1px solid var(--line);color:var(--text);padding:.8rem 1.1rem;
    border-radius:12px;z-index:50;opacity:0;transition:.25s;max-width:90vw;box-shadow:0 12px 40px rgba(0,0,0,.4)}
  .toast.show{opacity:1;transform:translateX(-50%) translateY(0)}
  .toast.ok{border-color:var(--ok)} .toast.err{border-color:var(--danger)}
  .receipt{font-size:.85rem;line-height:1.5}
  .receipt b{color:var(--brand-2)}
  .pill{display:inline-block;padding:.1rem .5rem;border-radius:999px;font-size:.72rem;font-weight:700}
  .pill.ok{background:rgba(46,204,113,.15);color:var(--ok)}
</style>
</head>
<body>
<header>
  <div class="bar">
    <div class="logo"><span class="dot"></span> Nimbus <small>Store</small></div>
    <div class="spacer"></div>
    <button class="cart-btn" onclick="openCart()">🛒 Cart<span class="badge" id="badge" style="display:none">0</span></button>
  </div>
</header>

<section class="hero">
  <h1>Everyday essentials, delivered.</h1>
  <p>A reference storefront running across five microservices on Kubernetes.</p>
  <div class="filters" id="filters"></div>
</section>

<main><div class="grid" id="grid"></div></main>

<div class="overlay" id="overlay" onclick="closeCart()"></div>
<aside class="drawer" id="drawer">
  <header><h2>Your cart</h2><button class="close" onclick="closeCart()">&times;</button></header>
  <div class="items" id="cartItems"></div>
  <div class="foot">
    <div class="total"><span>Total</span><span id="total">$0.00</span></div>
    <button class="checkout" id="checkoutBtn" onclick="checkout()" disabled>Checkout</button>
  </div>
</aside>

<div class="toast" id="toast"></div>

<script>
const USER = "web-" + Math.random().toString(36).slice(2, 8);
const EMOJI = {apparel:"👕",electronics:"🖱️",home:"☕",fitness:"🧘",default:"📦"};
let PRODUCTS = [], CART = {}, activeCat = "all";

const money = n => "$" + Number(n).toFixed(2);
const emojiFor = c => EMOJI[c] || EMOJI.default;

async function load(){
  const r = await fetch("/api/products");
  const d = await r.json();
  PRODUCTS = d.products || [];
  renderFilters();
  render();
}

function renderFilters(){
  const cats = ["all", ...new Set(PRODUCTS.map(p => p.category))];
  document.getElementById("filters").innerHTML = cats.map(c =>
    '<button class="chip ' + (c===activeCat?"active":"") + '" onclick="setCat(\\''+c+'\\')">' + c + '</button>'
  ).join("");
}
function setCat(c){ activeCat = c; renderFilters(); render(); }

function render(){
  const list = activeCat==="all" ? PRODUCTS : PRODUCTS.filter(p => p.category===activeCat);
  document.getElementById("grid").innerHTML = list.map(p => {
    const out = p.stock <= 0;
    return '<div class="card">' +
      '<div class="thumb">' + emojiFor(p.category) + '</div>' +
      '<div class="body">' +
        '<div class="cat">' + p.category + '</div>' +
        '<h3>' + p.name + '</h3>' +
        '<div class="row">' +
          '<span class="price">' + money(p.price) + '</span>' +
          '<button class="add" ' + (out?"disabled":"") + ' onclick="add(\\''+p.id+'\\')">' +
            (out?"Sold out":"Add") + '</button>' +
        '</div>' +
        '<div class="stock">' + (out?"Out of stock":(p.stock + " in stock")) + '</div>' +
      '</div></div>';
  }).join("");
}

async function add(id){
  CART[id] = (CART[id] || 0) + 1;
  updateCart();
  try{
    await fetch("/api/cart/" + USER + "/items", {
      method:"POST", headers:{"content-type":"application/json"},
      body: JSON.stringify({ productId:id, quantity:1 })
    });
    const p = PRODUCTS.find(x => x.id===id);
    toast("Added " + p.name + " to cart", "ok");
  }catch(e){ toast("Could not reach cart service", "err"); }
}

function cartTotal(){
  return Object.entries(CART).reduce((s,[id,q]) => {
    const p = PRODUCTS.find(x => x.id===id); return s + (p ? p.price*q : 0);
  }, 0);
}
function cartCount(){ return Object.values(CART).reduce((a,b)=>a+b,0); }

function updateCart(){
  const badge = document.getElementById("badge");
  const n = cartCount();
  badge.style.display = n ? "grid" : "none";
  badge.textContent = n;
  const items = Object.entries(CART);
  document.getElementById("cartItems").innerHTML = items.length ? items.map(([id,q]) => {
    const p = PRODUCTS.find(x => x.id===id) || {name:id,price:0,category:"default"};
    return '<div class="item">' +
      '<div class="emoji">' + emojiFor(p.category) + '</div>' +
      '<div class="grow"><div class="nm">' + p.name + '</div>' +
      '<div class="mut">' + money(p.price) + ' each</div></div>' +
      '<div class="qty">×' + q + '</div></div>';
  }).join("") : '<div class="empty">Your cart is empty.<br>Add something nice.</div>';
  document.getElementById("total").textContent = money(cartTotal());
  document.getElementById("checkoutBtn").disabled = items.length === 0;
}

function openCart(){ document.getElementById("drawer").classList.add("open");
  document.getElementById("overlay").classList.add("open"); }
function closeCart(){ document.getElementById("drawer").classList.remove("open");
  document.getElementById("overlay").classList.remove("open"); }

async function checkout(){
  const btn = document.getElementById("checkoutBtn");
  btn.disabled = true; btn.textContent = "Processing…";
  const items = Object.entries(CART).map(([productId,quantity]) => ({productId,quantity}));
  try{
    const r = await fetch("/api/orders", {
      method:"POST", headers:{"content-type":"application/json"},
      body: JSON.stringify({ userId:USER, items, total: Number(cartTotal().toFixed(2)) })
    });
    const d = await r.json();
    if(!r.ok) throw new Error(d.error || "checkout failed");
    toast('<div class="receipt">✅ <b>Order placed!</b><br>' +
      'Order <b>' + d.order.id.slice(0,8) + '</b> — <span class="pill ok">' + d.order.status + '</span><br>' +
      'Payment <b>' + money(d.payment.amount) + '</b> — <span class="pill ok">' + d.payment.status + '</span>' +
      '</div>', "ok", 5000);
    CART = {}; updateCart(); closeCart();
  }catch(e){ toast("Checkout failed: " + e.message, "err"); }
  finally{ btn.textContent = "Checkout"; btn.disabled = false; }
}

let toastT;
function toast(html, kind, ms){
  const t = document.getElementById("toast");
  t.className = "toast show " + (kind||"");
  t.innerHTML = html;
  clearTimeout(toastT);
  toastT = setTimeout(() => t.className = "toast " + (kind||""), ms || 2600);
}

load();
</script>
</body>
</html>`;

app.get("/", (_req, res) => {
  res.type("html").send(STOREFRONT_HTML);
});

app.get("/api/products", async (_req, res) => {
  try {
    const data = await fetchJson(`${CATALOG_URL}/products`);
    res.json(data);
  } catch (err) {
    log.error({ err: err.message }, "catalog upstream failed");
    res.status(502).json({ error: "upstream_unavailable" });
  }
});

app.post("/api/cart/:userId/items", async (req, res) => {
  try {
    const r = await fetch(`${CART_URL}/cart/${req.params.userId}/items`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(req.body),
    });
    res.status(r.status).send(await r.text());
  } catch (err) {
    res.status(502).json({ error: "upstream_unavailable" });
  }
});

app.post("/api/orders", async (req, res) => {
  try {
    const order = await fetchJson(`${ORDER_URL}/orders`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(req.body),
    });
    const payment = await fetchJson(`${PAYMENT_URL}/payments`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ orderId: order.id, amount: req.body.total, method: "card" }),
    });
    await fetchJson(`${ORDER_URL}/orders/${order.id}/confirm`, { method: "POST" });
    res.status(201).json({ order, payment });
  } catch (err) {
    log.error({ err: err.message }, "checkout failed");
    res.status(502).json({ error: "checkout_failed" });
  }
});

app.get("/metrics", async (_req, res) => {
  res.set("Content-Type", register.contentType);
  res.end(await register.metrics());
});

const PORT = parseInt(process.env.PORT || "8080", 10);
app.listen(PORT, () => log.info({ port: PORT }, "frontend listening"));
