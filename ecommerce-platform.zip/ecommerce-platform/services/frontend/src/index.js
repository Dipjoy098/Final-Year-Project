const express = require("express");
const pino = require("pino");
const pinoHttp = require("pino-http");
const client = require("prom-client");

const log = pino({ level: process.env.LOG_LEVEL || "info" });
const app = express();
app.use(express.json());
app.use(pinoHttp({ logger: log }));

const CATALOG_URL = process.env.CATALOG_URL || "http://catalog:8080";
const CART_URL    = process.env.CART_URL    || "http://cart:8080";
const ORDER_URL   = process.env.ORDER_URL   || "http://order:8080";
const PAYMENT_URL = process.env.PAYMENT_URL || "http://payment:8080";

const register = new client.Registry();
client.collectDefaultMetrics({ register });
const httpDuration = new client.Histogram({
  name: "http_request_duration_seconds",
  help: "HTTP request duration in seconds",
  labelNames: ["method", "route", "status"],
  buckets: [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10],
});
register.registerMetric(httpDuration);

app.use((req, res, next) => {
  const end = httpDuration.startTimer();
  res.on("finish", () => {
    end({ method: req.method, route: req.route?.path || req.path, status: res.statusCode });
  });
  next();
});

const fetchJson = async (url, opts = {}) => {
  const res = await fetch(url, opts);
  if (!res.ok) throw new Error(`upstream ${res.status} from ${url}`);
  return res.json();
};

app.get("/healthz", (_req, res) => res.json({ status: "ok" }));
app.get("/readyz",  (_req, res) => res.json({ status: "ready" }));

const STOREFRONT_HTML = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Feastly — Food Delivery</title>
<style>
  :root{
    --bg:#fff7f1; --panel:#ffffff; --line:#f0e6dd; --ink:#1c1c28; --muted:#7a7a8c;
    --brand:#fc8019; --brand-2:#ff5200; --brand-soft:#fff0e3;
    --veg:#3d9a50; --nonveg:#b1382e; --star:#ffb300; --radius:18px;
    --shadow:0 10px 30px rgba(252,128,25,.10);
  }
  *{box-sizing:border-box}
  html{scroll-behavior:smooth}
  body{margin:0;font-family:'Inter',system-ui,-apple-system,Segoe UI,Roboto,sans-serif;
    background:var(--bg);color:var(--ink);min-height:100vh}
  ::-webkit-scrollbar{width:10px;height:10px}
  ::-webkit-scrollbar-thumb{background:#f0d9c6;border-radius:20px}

  /* ---- header ---- */
  header{position:sticky;top:0;z-index:30;backdrop-filter:blur(12px);
    background:rgba(255,255,255,.82);border-bottom:1px solid var(--line)}
  .bar{max-width:1140px;margin:0 auto;display:flex;align-items:center;gap:1rem;padding:.85rem 1.25rem}
  .logo{display:flex;align-items:center;gap:.5rem;font-weight:900;font-size:1.4rem;letter-spacing:-.03em}
  .logo .mark{font-size:1.5rem;animation:bob 2.4s ease-in-out infinite}
  .logo b{background:linear-gradient(135deg,var(--brand),var(--brand-2));-webkit-background-clip:text;background-clip:text;color:transparent}
  .loc{display:flex;align-items:center;gap:.35rem;color:var(--muted);font-size:.85rem;font-weight:600}
  .loc b{color:var(--ink)}
  .spacer{flex:1}
  .cart-btn{position:relative;border:0;background:linear-gradient(135deg,var(--brand),var(--brand-2));
    color:#fff;border-radius:999px;padding:.6rem 1.15rem;cursor:pointer;font-weight:800;font-size:.92rem;
    box-shadow:var(--shadow);transition:transform .15s}
  .cart-btn:active{transform:scale(.94)}
  .badge{position:absolute;top:-6px;right:-6px;min-width:22px;height:22px;border-radius:999px;
    background:#fff;color:var(--brand-2);font-size:.75rem;font-weight:900;display:grid;place-items:center;
    padding:0 5px;border:2px solid var(--brand);box-shadow:0 2px 8px rgba(0,0,0,.15)}
  .badge.pop{animation:pop .4s ease}

  /* ---- hero ---- */
  .hero{position:relative;overflow:hidden;color:#fff;
    background:linear-gradient(120deg,#ff5200,#fc8019 60%,#ffa251)}
  .hero .inner{max-width:1140px;margin:0 auto;padding:2.6rem 1.25rem 2.9rem;position:relative;z-index:2}
  .hero h1{font-size:2.5rem;line-height:1.08;margin:.2rem 0;letter-spacing:-.035em;font-weight:900;
    animation:rise .6s ease both}
  .hero p{font-size:1.05rem;opacity:.95;margin:.5rem 0 1.25rem;animation:rise .6s .08s ease both}
  .search{display:flex;align-items:center;gap:.6rem;background:#fff;border-radius:14px;padding:.85rem 1.1rem;
    max-width:560px;box-shadow:0 14px 40px rgba(0,0,0,.18);animation:rise .6s .16s ease both}
  .search input{border:0;outline:0;flex:1;font-size:1rem;color:var(--ink);background:transparent}
  .search .mag{font-size:1.15rem}
  .floaty{position:absolute;font-size:3.4rem;opacity:.35;z-index:1;filter:drop-shadow(0 8px 14px rgba(0,0,0,.15))}
  .f1{top:18px;right:6%;animation:float1 6s ease-in-out infinite}
  .f2{bottom:14px;right:20%;animation:float2 7s ease-in-out infinite}
  .f3{top:40px;right:34%;animation:float1 5s ease-in-out infinite}

  /* ---- categories ---- */
  .cats-wrap{max-width:1140px;margin:1.5rem auto .25rem;padding:0 1.25rem}
  .cats-wrap h2,.sec h2{font-size:1.2rem;margin:0 0 .8rem;letter-spacing:-.02em}
  .cats{display:flex;gap:.7rem;overflow-x:auto;padding:.25rem .1rem .8rem;scrollbar-width:none}
  .cats::-webkit-scrollbar{display:none}
  .cat{flex:0 0 auto;display:flex;flex-direction:column;align-items:center;gap:.4rem;cursor:pointer;
    padding:.55rem;border-radius:16px;transition:transform .15s;min-width:82px}
  .cat:hover{transform:translateY(-4px)}
  .cat .ic{width:62px;height:62px;border-radius:50%;display:grid;place-items:center;font-size:1.9rem;
    background:var(--panel);border:1px solid var(--line);box-shadow:var(--shadow);transition:.18s}
  .cat.active .ic{background:var(--brand);border-color:var(--brand);transform:scale(1.06)}
  .cat span{font-size:.78rem;font-weight:700;text-transform:capitalize;color:var(--muted)}
  .cat.active span{color:var(--brand-2)}

  /* ---- toolbar ---- */
  .toolbar{max-width:1140px;margin:.4rem auto 0;padding:0 1.25rem;display:flex;align-items:center;gap:.6rem;flex-wrap:wrap}
  .toggle{display:flex;align-items:center;gap:.5rem;background:var(--panel);border:1px solid var(--line);
    border-radius:999px;padding:.4rem .75rem;font-size:.82rem;font-weight:700;cursor:pointer;user-select:none}
  .switch{width:38px;height:22px;border-radius:999px;background:#e3e3ea;position:relative;transition:.2s}
  .switch::after{content:"";position:absolute;top:2px;left:2px;width:18px;height:18px;border-radius:50%;
    background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.25);transition:.2s}
  .toggle.on .switch{background:var(--veg)} .toggle.on .switch::after{left:18px}
  .toggle.nv.on .switch{background:var(--nonveg)}
  .count{margin-left:auto;color:var(--muted);font-size:.82rem;font-weight:600}

  /* ---- grid ---- */
  .sec{max-width:1140px;margin:1.1rem auto 5.5rem;padding:0 1.25rem}
  .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(255px,1fr));gap:1.2rem}
  .card{background:var(--panel);border:1px solid var(--line);border-radius:var(--radius);overflow:hidden;
    display:flex;flex-direction:column;box-shadow:0 4px 18px rgba(28,28,40,.05);
    transition:transform .18s,box-shadow .18s;animation:rise .5s ease both}
  .card:hover{transform:translateY(-6px);box-shadow:0 18px 42px rgba(252,128,25,.18)}
  .thumb{height:150px;position:relative;display:grid;place-items:center;font-size:4rem;
    background:radial-gradient(120% 120% at 30% 15%,#fff2e6,#ffe3cc)}
  .thumb .big{transition:transform .3s} .card:hover .thumb .big{transform:scale(1.14) rotate(-4deg)}
  .ribbon{position:absolute;top:10px;left:0;background:linear-gradient(135deg,var(--brand),var(--brand-2));
    color:#fff;font-size:.66rem;font-weight:800;padding:.28rem .6rem .28rem .55rem;border-radius:0 8px 8px 0;
    text-transform:uppercase;letter-spacing:.04em;box-shadow:0 4px 12px rgba(255,82,0,.4)}
  .eta{position:absolute;bottom:10px;right:10px;background:rgba(255,255,255,.92);color:var(--ink);
    font-size:.72rem;font-weight:800;padding:.25rem .55rem;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,.12)}
  .vmark{position:absolute;top:10px;right:10px;width:18px;height:18px;border:2px solid;border-radius:4px;
    display:grid;place-items:center;background:#fff}
  .vmark::after{content:"";width:8px;height:8px;border-radius:50%}
  .vmark.veg{border-color:var(--veg)} .vmark.veg::after{background:var(--veg)}
  .vmark.non{border-color:var(--nonveg)} .vmark.non::after{background:var(--nonveg)}
  .body{padding:.9rem 1rem 1rem;display:flex;flex-direction:column;gap:.35rem;flex:1}
  .body h3{margin:0;font-size:1.05rem;letter-spacing:-.01em}
  .rest{font-size:.78rem;color:var(--muted);font-weight:600}
  .rate{display:inline-flex;align-items:center;gap:.25rem;background:var(--veg);color:#fff;
    font-size:.72rem;font-weight:800;padding:.12rem .4rem;border-radius:6px}
  .desc{font-size:.8rem;color:var(--muted);line-height:1.35;min-height:2.1em}
  .row{display:flex;align-items:center;justify-content:space-between;margin-top:auto;padding-top:.55rem}
  .price{font-weight:900;font-size:1.15rem}
  .price small{color:var(--muted);font-weight:600;font-size:.8rem}
  .add{border:1.5px solid var(--brand);border-radius:11px;background:var(--brand-soft);color:var(--brand-2);
    font-weight:800;padding:.5rem 1.1rem;cursor:pointer;font-size:.85rem;transition:.15s;letter-spacing:.02em}
  .add:hover{background:var(--brand);color:#fff}
  .add:disabled{border-color:#ddd;background:#f4f4f6;color:#aaa;cursor:not-allowed}
  /* qty stepper */
  .stepper{display:inline-flex;align-items:center;border:1.5px solid var(--brand);border-radius:11px;overflow:hidden}
  .stepper button{border:0;background:var(--brand-soft);color:var(--brand-2);font-weight:900;font-size:1rem;
    width:32px;height:34px;cursor:pointer;transition:.12s}
  .stepper button:hover{background:var(--brand);color:#fff}
  .stepper .n{min-width:26px;text-align:center;font-weight:800;color:var(--brand-2)}

  /* ---- skeleton ---- */
  .sk{background:var(--panel);border:1px solid var(--line);border-radius:var(--radius);overflow:hidden;height:290px}
  .sk .b{height:150px;background:linear-gradient(90deg,#f3ece5 25%,#faf4ee 37%,#f3ece5 63%);
    background-size:400% 100%;animation:shimmer 1.3s infinite}
  .sk .l{height:12px;margin:14px 16px;border-radius:6px;
    background:linear-gradient(90deg,#f3ece5 25%,#faf4ee 37%,#f3ece5 63%);background-size:400% 100%;
    animation:shimmer 1.3s infinite}

  /* ---- floating cart bar (mobile-first Swiggy touch) ---- */
  .fab{position:fixed;left:50%;bottom:1.1rem;transform:translateX(-50%) translateY(160%);z-index:35;
    width:min(560px,92vw);background:linear-gradient(135deg,#3d9a50,#2f8040);color:#fff;border-radius:16px;
    padding:.85rem 1.15rem;display:flex;align-items:center;gap:.9rem;cursor:pointer;
    box-shadow:0 16px 40px rgba(61,154,80,.4);transition:transform .35s cubic-bezier(.2,1.3,.5,1)}
  .fab.show{transform:translateX(-50%) translateY(0)}
  .fab .l{font-size:.8rem;font-weight:600;opacity:.9} .fab .r{font-weight:800}
  .fab .go{margin-left:auto;font-weight:900;display:flex;align-items:center;gap:.4rem}

  /* ---- drawer ---- */
  .overlay{position:fixed;inset:0;background:rgba(20,10,0,.45);opacity:0;pointer-events:none;transition:.25s;z-index:40}
  .overlay.open{opacity:1;pointer-events:auto}
  .drawer{position:fixed;top:0;right:0;height:100%;width:min(430px,94vw);z-index:50;background:var(--bg);
    box-shadow:-20px 0 60px rgba(0,0,0,.2);transform:translateX(100%);transition:transform .3s cubic-bezier(.3,1,.4,1);
    display:flex;flex-direction:column}
  .drawer.open{transform:translateX(0)}
  .dhead{padding:1.2rem 1.3rem;display:flex;align-items:center;background:var(--panel);border-bottom:1px solid var(--line)}
  .dhead h2{margin:0;font-size:1.25rem}
  .close{margin-left:auto;background:none;border:0;color:var(--muted);font-size:1.7rem;cursor:pointer;line-height:1}
  .items{flex:1;overflow:auto;padding:.6rem 1.3rem}
  .item{display:flex;gap:.8rem;align-items:center;padding:.8rem 0;border-bottom:1px dashed var(--line);animation:rise .35s ease both}
  .item .em{font-size:1.9rem}
  .item .grow{flex:1}
  .item .nm{font-size:.95rem;font-weight:700}
  .item .mut{font-size:.78rem;color:var(--muted)}
  .mini{display:inline-flex;align-items:center;border:1.5px solid var(--brand);border-radius:9px;overflow:hidden;margin-top:.3rem}
  .mini button{border:0;background:var(--brand-soft);color:var(--brand-2);font-weight:900;width:26px;height:28px;cursor:pointer}
  .mini button:hover{background:var(--brand);color:#fff}
  .mini .n{min-width:22px;text-align:center;font-weight:800;color:var(--brand-2);font-size:.85rem}
  .item .lp{font-weight:800}
  .empty{text-align:center;padding:3rem 1rem;color:var(--muted)}
  .empty .em{font-size:3.5rem;display:block;margin-bottom:.5rem;animation:bob 2.4s ease-in-out infinite}
  .foot{padding:1.1rem 1.3rem;background:var(--panel);border-top:1px solid var(--line)}
  .line{display:flex;justify-content:space-between;font-size:.85rem;color:var(--muted);margin-bottom:.35rem}
  .total{display:flex;justify-content:space-between;font-weight:900;font-size:1.25rem;margin:.5rem 0 .9rem}
  .checkout{width:100%;border:0;border-radius:13px;background:linear-gradient(135deg,var(--brand),var(--brand-2));
    color:#fff;font-weight:900;font-size:1.05rem;padding:.95rem;cursor:pointer;box-shadow:var(--shadow);transition:transform .12s}
  .checkout:active{transform:scale(.98)} .checkout:disabled{opacity:.55;cursor:not-allowed}

  /* ---- order tracking modal ---- */
  .modal{position:fixed;inset:0;z-index:60;display:grid;place-items:center;background:rgba(20,10,0,.55);
    opacity:0;pointer-events:none;transition:.25s}
  .modal.open{opacity:1;pointer-events:auto}
  .track{background:var(--panel);border-radius:22px;width:min(420px,92vw);padding:1.6rem;text-align:center;
    box-shadow:0 30px 80px rgba(0,0,0,.35);transform:scale(.85);transition:transform .3s cubic-bezier(.2,1.4,.5,1)}
  .modal.open .track{transform:scale(1)}
  .track .rider{font-size:3.5rem;animation:drive 1.2s ease-in-out infinite}
  .track h3{margin:.4rem 0 .1rem;font-size:1.35rem}
  .track .oid{color:var(--muted);font-size:.82rem;margin-bottom:1.1rem}
  .steps{display:flex;flex-direction:column;gap:0;text-align:left;margin:0 auto;max-width:280px}
  .step{display:flex;align-items:center;gap:.8rem;padding:.5rem 0;opacity:.4;transition:.35s}
  .step.done{opacity:1}
  .step .dot{width:26px;height:26px;border-radius:50%;background:#e6e6ec;color:#fff;display:grid;place-items:center;
    font-size:.8rem;font-weight:900;flex:0 0 auto;transition:.35s}
  .step.done .dot{background:var(--veg)}
  .step .tx{font-weight:700;font-size:.92rem}
  .step.cur .dot{background:var(--brand);animation:pulse 1s infinite}
  .track .done-msg{margin-top:1rem;font-weight:800;color:var(--veg);opacity:0;transition:.4s}
  .track .done-msg.show{opacity:1}
  .track .paybox{margin-top:.9rem;font-size:.82rem;color:var(--muted)}
  .track .close2{margin-top:1.1rem;border:0;background:var(--brand-soft);color:var(--brand-2);font-weight:800;
    border-radius:11px;padding:.7rem 1.4rem;cursor:pointer;font-size:.9rem}

  .toast{position:fixed;bottom:5.5rem;left:50%;transform:translateX(-50%) translateY(20px);z-index:70;
    background:var(--ink);color:#fff;padding:.75rem 1.15rem;border-radius:12px;opacity:0;transition:.28s;
    font-weight:700;font-size:.88rem;box-shadow:0 12px 40px rgba(0,0,0,.35);max-width:90vw}
  .toast.show{opacity:1;transform:translateX(-50%) translateY(0)}
  .toast.err{background:var(--nonveg)}

  /* ---- keyframes ---- */
  @keyframes rise{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}
  @keyframes pop{0%{transform:scale(1)}40%{transform:scale(1.5)}100%{transform:scale(1)}}
  @keyframes bob{0%,100%{transform:translateY(0)}50%{transform:translateY(-6px)}}
  @keyframes shimmer{0%{background-position:100% 0}100%{background-position:-100% 0}}
  @keyframes float1{0%,100%{transform:translateY(0) rotate(0)}50%{transform:translateY(-16px) rotate(8deg)}}
  @keyframes float2{0%,100%{transform:translateY(0) rotate(0)}50%{transform:translateY(14px) rotate(-8deg)}}
  @keyframes drive{0%,100%{transform:translateX(-8px)}50%{transform:translateX(8px)}}
  @keyframes pulse{0%,100%{box-shadow:0 0 0 0 rgba(252,128,25,.5)}50%{box-shadow:0 0 0 8px rgba(252,128,25,0)}}
  @keyframes fly{to{transform:translate(var(--dx),var(--dy)) scale(.2);opacity:0}}
  .flyer{position:fixed;z-index:80;font-size:2rem;pointer-events:none;animation:fly .7s cubic-bezier(.5,-0.4,.7,1) forwards}
  @media(max-width:600px){.hero h1{font-size:1.9rem}}
</style>
</head>
<body>
<header>
  <div class="bar">
    <div class="logo"><span class="mark">🛵</span> <span>Feast<b>ly</b></span></div>
    <div class="loc">📍 Deliver to <b>Home</b> ▾</div>
    <div class="spacer"></div>
    <button class="cart-btn" onclick="openCart()">🛒 Cart<span class="badge" id="badge" style="display:none">0</span></button>
  </div>
</header>

<section class="hero">
  <span class="floaty f1">🍕</span><span class="floaty f2">🍔</span><span class="floaty f3">🍜</span>
  <div class="inner">
    <h1>Hungry? Order in.<br>Delivered in minutes.</h1>
    <p>Your favourite meals from the best kitchens, powered by Kubernetes.</p>
    <div class="search">
      <span class="mag">🔍</span>
      <input id="search" placeholder="Search for dishes, e.g. biryani, pizza…" oninput="render()" />
    </div>
  </div>
</section>

<div class="cats-wrap">
  <h2>What's on your mind?</h2>
  <div class="cats" id="cats"></div>
</div>

<div class="toolbar">
  <div class="toggle veg" id="vegT" onclick="toggleDiet('veg')"><span class="switch"></span> 🟢 Veg</div>
  <div class="toggle nv" id="nvT" onclick="toggleDiet('non')"><span class="switch"></span> 🔴 Non-veg</div>
  <div class="count" id="count"></div>
</div>

<div class="sec">
  <h2 id="secTitle">Top picks near you</h2>
  <div class="grid" id="grid"></div>
</div>

<!-- floating cart bar -->
<div class="fab" id="fab" onclick="openCart()">
  <span class="l" id="fabCount">0 items</span>
  <span class="r" id="fabTotal">₹0</span>
  <span class="go">View cart ➜</span>
</div>

<div class="overlay" id="overlay" onclick="closeCart()"></div>
<aside class="drawer" id="drawer">
  <div class="dhead"><h2>Your order 🛍️</h2><button class="close" onclick="closeCart()">&times;</button></div>
  <div class="items" id="cartItems"></div>
  <div class="foot">
    <div class="line"><span>Item total</span><span id="subtotal">₹0</span></div>
    <div class="line"><span>Delivery fee</span><span id="delFee">₹0</span></div>
    <div class="total"><span>To pay</span><span id="total">₹0</span></div>
    <button class="checkout" id="checkoutBtn" onclick="checkout()" disabled>Proceed to pay</button>
  </div>
</aside>

<!-- order tracking -->
<div class="modal" id="modal">
  <div class="track">
    <div class="rider">🛵</div>
    <h3 id="trackTitle">Placing your order…</h3>
    <div class="oid" id="trackOid"></div>
    <div class="steps" id="steps"></div>
    <div class="paybox" id="payBox"></div>
    <div class="done-msg" id="doneMsg">🎉 Enjoy your meal!</div>
    <button class="close2" id="close2" onclick="closeModal()" style="display:none">Order again</button>
  </div>
</div>

<div class="toast" id="toast"></div>

<script>
const USER = "web-" + Math.random().toString(36).slice(2, 8);
const CAT_ICON = {pizza:"🍕",burgers:"🍔",biryani:"🍛","south-indian":"🥘",chinese:"🍜",
  desserts:"🍰",beverages:"🥤","north-indian":"🍗",all:"🍽️"};
let PRODUCTS = [], CART = {}, activeCat = "all", diet = null; // diet: null|'veg'|'non'

const money = n => "₹" + Math.round(Number(n));
const iconFor = c => CAT_ICON[c] || "🍽️";

function skeletons(){
  document.getElementById("grid").innerHTML =
    Array.from({length:8}).map(() =>
      '<div class="sk"><div class="b"></div><div class="l" style="width:70%"></div>' +
      '<div class="l" style="width:45%"></div><div class="l" style="width:60%"></div></div>').join("");
}

async function load(){
  skeletons();
  try{
    const r = await fetch("/api/products");
    const d = await r.json();
    PRODUCTS = d.products || [];
  }catch(e){ toast("Couldn't load the menu", "err"); PRODUCTS = []; }
  renderCats();
  render();
}

function renderCats(){
  const cats = ["all", ...Array.from(new Set(PRODUCTS.map(p => p.category)))];
  document.getElementById("cats").innerHTML = cats.map(c =>
    '<div class="cat ' + (c===activeCat?"active":"") + '" onclick="setCat(\\''+c+'\\')">' +
      '<div class="ic">' + iconFor(c) + '</div><span>' + (c==="all"?"All":c.replace("-"," ")) + '</span></div>'
  ).join("");
}
function setCat(c){ activeCat = c; renderCats(); render(); }

function toggleDiet(d){
  diet = (diet===d) ? null : d;
  document.getElementById("vegT").classList.toggle("on", diet==="veg");
  document.getElementById("nvT").classList.toggle("on", diet==="non");
  render();
}

function visible(){
  const q = (document.getElementById("search").value || "").toLowerCase().trim();
  return PRODUCTS.filter(p => {
    if(activeCat!=="all" && p.category!==activeCat) return false;
    if(diet==="veg" && !p.veg) return false;
    if(diet==="non" && p.veg) return false;
    if(q && !(p.name.toLowerCase().includes(q) || (p.restaurant||"").toLowerCase().includes(q) ||
             p.category.toLowerCase().includes(q))) return false;
    return true;
  });
}

function render(){
  const list = visible();
  const title = activeCat==="all" ? "Top picks near you" : activeCat.replace("-"," ") + " for you";
  document.getElementById("secTitle").textContent = title;
  document.getElementById("count").textContent = list.length + " dishes";
  const grid = document.getElementById("grid");
  if(!list.length){ grid.innerHTML = '<div class="empty" style="grid-column:1/-1"><span class="em">🍽️</span>No dishes match. Try another filter.</div>'; return; }
  grid.innerHTML = list.map((p,i) => {
    const q = CART[p.id] || 0;
    const control = q>0
      ? '<div class="stepper"><button onclick="dec(\\''+p.id+'\\')">−</button>' +
        '<span class="n" id="n-'+p.id+'">'+q+'</span><button onclick="add(\\''+p.id+'\\',event)">+</button></div>'
      : '<button class="add" onclick="add(\\''+p.id+'\\',event)">ADD +</button>';
    return '<div class="card" style="animation-delay:'+(i*40)+'ms">' +
      '<div class="thumb">' +
        (p.bestseller ? '<div class="ribbon">★ Bestseller</div>' : '') +
        '<div class="vmark ' + (p.veg?"veg":"non") + '"></div>' +
        '<div class="big">' + (p.emoji||"🍽️") + '</div>' +
        '<div class="eta">⏱ ' + (p.eta||25) + ' min</div>' +
      '</div>' +
      '<div class="body">' +
        '<div style="display:flex;justify-content:space-between;align-items:center;gap:.5rem">' +
          '<h3>' + p.name + '</h3>' +
          '<span class="rate">★ ' + (p.rating||4.2).toFixed(1) + '</span>' +
        '</div>' +
        '<div class="rest">🏠 ' + (p.restaurant||"Feastly Kitchen") + '</div>' +
        '<div class="desc">' + (p.desc||"") + '</div>' +
        '<div class="row"><span class="price">' + money(p.price) + '</span>' + control + '</div>' +
      '</div></div>';
  }).join("");
}

function flyToCart(ev, emoji){
  if(!ev) return;
  const f = document.createElement("div");
  f.className = "flyer"; f.textContent = emoji || "🍽️";
  const x = ev.clientX, y = ev.clientY;
  const cart = document.getElementById("badge").getBoundingClientRect();
  f.style.left = x + "px"; f.style.top = y + "px";
  f.style.setProperty("--dx", (cart.left - x) + "px");
  f.style.setProperty("--dy", (cart.top - y) + "px");
  document.body.appendChild(f);
  setTimeout(() => f.remove(), 700);
}

async function add(id, ev){
  const p = PRODUCTS.find(x => x.id===id);
  CART[id] = (CART[id] || 0) + 1;
  flyToCart(ev, p && p.emoji);
  bumpBadge();
  render(); updateCart();
  try{
    await fetch("/api/cart/" + USER + "/items", {
      method:"POST", headers:{"content-type":"application/json"},
      body: JSON.stringify({ productId:id, quantity:1 })
    });
  }catch(e){ toast("Cart service unreachable", "err"); }
}
function dec(id){
  if(!CART[id]) return;
  CART[id]--; if(CART[id]<=0) delete CART[id];
  render(); updateCart();
}

function cartTotal(){
  return Object.entries(CART).reduce((s,[id,q]) => {
    const p = PRODUCTS.find(x => x.id===id); return s + (p ? p.price*q : 0);
  }, 0);
}
function cartCount(){ return Object.values(CART).reduce((a,b)=>a+b,0); }
const DELIVERY = 29;

function bumpBadge(){
  const b = document.getElementById("badge");
  b.classList.remove("pop"); void b.offsetWidth; b.classList.add("pop");
}

function updateCart(){
  const n = cartCount();
  const badge = document.getElementById("badge");
  badge.style.display = n ? "grid" : "none";
  badge.textContent = n;
  // floating bar
  const fab = document.getElementById("fab");
  fab.classList.toggle("show", n>0);
  document.getElementById("fabCount").textContent = n + (n===1?" item":" items");
  document.getElementById("fabTotal").textContent = money(cartTotal());
  // drawer
  const items = Object.entries(CART);
  document.getElementById("cartItems").innerHTML = items.length ? items.map(([id,q]) => {
    const p = PRODUCTS.find(x => x.id===id) || {name:id,price:0,emoji:"🍽️"};
    return '<div class="item">' +
      '<div class="em">' + (p.emoji||"🍽️") + '</div>' +
      '<div class="grow"><div class="nm">' + p.name + '</div>' +
      '<div class="mut">' + money(p.price) + '</div>' +
      '<div class="mini"><button onclick="dec(\\''+id+'\\')">−</button>' +
      '<span class="n">'+q+'</span><button onclick="add(\\''+id+'\\')">+</button></div></div>' +
      '<div class="lp">' + money(p.price*q) + '</div></div>';
  }).join("") : '<div class="empty"><span class="em">🛒</span>Your cart is empty.<br>Add something delicious!</div>';
  const sub = cartTotal();
  document.getElementById("subtotal").textContent = money(sub);
  document.getElementById("delFee").textContent = sub>0 ? money(DELIVERY) : "₹0";
  document.getElementById("total").textContent = money(sub>0 ? sub+DELIVERY : 0);
  document.getElementById("checkoutBtn").disabled = items.length === 0;
}

function openCart(){ if(!cartCount()) return; document.getElementById("drawer").classList.add("open");
  document.getElementById("overlay").classList.add("open"); }
function closeCart(){ document.getElementById("drawer").classList.remove("open");
  document.getElementById("overlay").classList.remove("open"); }

const STEP_LABELS = [
  {t:"Order placed", ic:"✓"},
  {t:"Restaurant is preparing", ic:"👨‍🍳"},
  {t:"Rider picked up your order", ic:"🛵"},
  {t:"Delivered", ic:"🏠"},
];
function renderSteps(active){
  document.getElementById("steps").innerHTML = STEP_LABELS.map((s,i) =>
    '<div class="step ' + (i<active?"done":"") + (i===active?" cur":"") + '">' +
      '<span class="dot">' + (i<active?"✓":(i+1)) + '</span>' +
      '<span class="tx">' + s.t + '</span></div>'
  ).join("");
}
function openModal(){ document.getElementById("modal").classList.add("open"); }
function closeModal(){ document.getElementById("modal").classList.remove("open"); }

async function checkout(){
  const btn = document.getElementById("checkoutBtn");
  btn.disabled = true; btn.textContent = "Processing…";
  closeCart();
  document.getElementById("trackTitle").textContent = "Placing your order…";
  document.getElementById("trackOid").textContent = "";
  document.getElementById("payBox").textContent = "";
  document.getElementById("doneMsg").classList.remove("show");
  document.getElementById("close2").style.display = "none";
  renderSteps(0); openModal();

  const items = Object.entries(CART).map(([productId,quantity]) => ({productId,quantity}));
  try{
    const r = await fetch("/api/orders", {
      method:"POST", headers:{"content-type":"application/json"},
      body: JSON.stringify({ userId:USER, items, total: Number((cartTotal()+DELIVERY).toFixed(2)) })
    });
    const d = await r.json();
    if(!r.ok) throw new Error(d.error || "checkout failed");
    document.getElementById("trackTitle").textContent = "Order confirmed!";
    document.getElementById("trackOid").textContent = "Order #" + d.order.id.slice(0,8).toUpperCase();
    document.getElementById("payBox").innerHTML =
      "💳 Paid " + money(d.payment.amount) + " · " + d.payment.status;
    // animate through the delivery steps
    let step = 1;
    renderSteps(step);
    const timer = setInterval(() => {
      step++;
      if(step >= STEP_LABELS.length){
        clearInterval(timer);
        renderSteps(STEP_LABELS.length);
        document.getElementById("trackTitle").textContent = "Delivered 🎉";
        document.getElementById("doneMsg").classList.add("show");
        document.getElementById("close2").style.display = "inline-block";
      } else {
        renderSteps(step);
      }
    }, 1100);
    CART = {}; updateCart();
  }catch(e){
    closeModal();
    toast("Checkout failed: " + e.message, "err");
  }finally{ btn.textContent = "Proceed to pay"; btn.disabled = false; }
}

let toastT;
function toast(html, kind){
  const t = document.getElementById("toast");
  t.className = "toast show " + (kind||"");
  t.innerHTML = html;
  clearTimeout(toastT);
  toastT = setTimeout(() => t.className = "toast " + (kind||""), 2600);
}

load();
</script>
</body>
</html>`;

app.get("/", (_req, res) => {
  res.type("html").send(STOREFRONT_HTML);
});

app.get("/api/products", async (_req, res) => {
  try {
    const data = await fetchJson(`${CATALOG_URL}/products`);
    res.json(data);
  } catch (err) {
    log.error({ err: err.message }, "catalog upstream failed");
    res.status(502).json({ error: "upstream_unavailable" });
  }
});

app.post("/api/cart/:userId/items", async (req, res) => {
  try {
    const r = await fetch(`${CART_URL}/cart/${req.params.userId}/items`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(req.body),
    });
    res.status(r.status).send(await r.text());
  } catch (err) {
    res.status(502).json({ error: "upstream_unavailable" });
  }
});

app.post("/api/orders", async (req, res) => {
  try {
    const order = await fetchJson(`${ORDER_URL}/orders`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(req.body),
    });
    const payment = await fetchJson(`${PAYMENT_URL}/payments`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ orderId: order.id, amount: req.body.total, method: "card" }),
    });
    await fetchJson(`${ORDER_URL}/orders/${order.id}/confirm`, { method: "POST" });
    res.status(201).json({ order, payment });
  } catch (err) {
    log.error({ err: err.message }, "checkout failed");
    res.status(502).json({ error: "checkout_failed" });
  }
});

app.get("/metrics", async (_req, res) => {
  res.set("Content-Type", register.contentType);
  res.end(await register.metrics());
});

const PORT = parseInt(process.env.PORT || "8080", 10);
app.listen(PORT, () => log.info({ port: PORT }, "frontend listening"));
