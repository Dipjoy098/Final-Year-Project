# Deployment Guide (self-managed k3s, no AWS)

End-to-end deployment on local Ubuntu VMs. No cloud account required.

## Prerequisites

- [Multipass](https://multipass.run/) — `brew install --cask multipass`
- Terraform 1.7+, Ansible 9+, kubectl 1.29+, Helm 3.14+, Docker
- A container registry the VMs can reach. For a demo, run a local one:
  `docker run -d -p 5000:5000 --name registry registry:2`

## 1. Provision the VMs (Terraform)

Terraform owns the instance lifecycle. `apply` creates the VMs and writes the
Ansible inventory + SSH key; `destroy` deletes them.

```bash
cd terraform/environments/local-k8s
terraform init
terraform apply -var-file=local-k8s.tfvars
```

Adjust node count / sizing in `local-k8s.tfvars` (`agent_count`, `*_cpus`,
`*_memory`).

## 2. Install k3s + bootstrap (Ansible)

```bash
cd ../../../ansible
ansible-galaxy collection install -r requirements.yml
ansible-playbook -i inventories/local-k8s/hosts.ini playbooks/site.yml
```

This hardens the nodes, installs the k3s server + agents, writes a kubeconfig
to `ansible/.kube/config`, and creates the platform namespaces.

## 3. Build & push images

```bash
make build-images IMAGE_TAG=v1 REGISTRY=localhost:5000
```

## 4. Deploy the application (Ansible → Helm)

```bash
make deploy IMAGE_TAG=v1
```

## 5. Upgrades and rollbacks (Ansible)

```bash
# roll a new version out and verify every Deployment converges
make rollout IMAGE_TAG=v2

# revert to the previous release
make rollback
```

## 6. Tear down

```bash
cd terraform/environments/local-k8s
terraform destroy -var-file=local-k8s.tfvars
```

## Doing it all via Jenkins

Create a Pipeline job pointing at the repo's [Jenkinsfile](../Jenkinsfile). It
runs tests → builds → scans → pushes images → invokes the Ansible rollout
playbook (and rolls back automatically on failure). Set the `REGISTRY`
environment variable on the agent and ensure `ansible/.kube/config` is present
(produced by step 2).

## Optional: single-node kind cluster

For a quick app-only smoke test without VMs, `scripts/local-up.sh` spins up a
[kind](https://kind.sigs.k8s.io/) cluster and deploys with
`helm/ecommerce/values-local.yaml`. This does not exercise the Terraform or
Ansible paths.
