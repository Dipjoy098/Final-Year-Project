# Runbook

## On-call procedures

### High 5xx error rate

1. Check the Grafana **Ecommerce / Golden Signals** dashboard for the affected service.
2. Pull recent logs: `kubectl logs -l app.kubernetes.io/name=<svc> --tail=200`
3. Check upstream dependencies (catalog → DB; payment → mock gateway).
4. If a recent rollout is the cause, `helm rollback ecommerce <revision>`.

### Latency p95 > 500ms

1. Inspect HPA status: `kubectl get hpa -n ecommerce`.
2. If pods are at max replicas, check cluster autoscaler events and node capacity.
3. Look for slow-query logs in RDS Performance Insights.

### Payment failure spike

1. Check `payments_total{status="failed"}` rate in Grafana.
2. Confirm the `PAYMENT_FAILURE_RATE` env var hasn't been altered (config drift).
3. Page the payments owner if mock-gateway-related; else escalate to the third-party vendor.

## Disaster recovery

### Loss of an Availability Zone

EKS managed node groups will reschedule pods automatically. RDS Multi-AZ in
prod will fail over within 60-120s. Verify by:

- `kubectl get nodes` shows surviving AZs.
- RDS endpoint resolves to the standby IP after failover.
- Storefront synthetic check returns 200.

### Loss of the entire region

1. Restore RDS from the most recent cross-region snapshot.
2. `terraform apply` in the DR region with `-var=region=us-west-2`.
3. Update DNS to point to the new ALB.
