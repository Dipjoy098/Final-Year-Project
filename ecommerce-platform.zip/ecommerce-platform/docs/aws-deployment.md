# AWS Deployment Guide

> **Read before running.** This will create paid AWS resources. The dev
> environment costs roughly USD $4–6 per day if left running.

## Prerequisites

- AWS account with administrator access for the bootstrap step
- AWS CLI v2 configured (`aws sts get-caller-identity` works)
- Terraform 1.7+, Ansible 9+, kubectl 1.29+, Helm 3.14+, Docker
- A registered domain (optional, only for ACM/TLS)

## 1. Bootstrap state backend

Run once per AWS account:

```bash
./scripts/bootstrap-aws.sh
```

## 2. Provision an environment

```bash
cd terraform/environments/dev
terraform init
terraform plan  -var-file=dev.tfvars
terraform apply -var-file=dev.tfvars
```

Outputs include the EKS cluster name and RDS endpoint.

## 3. Configure kubeconfig

```bash
aws eks update-kubeconfig --name ecommerce-dev --region us-east-1
```

## 4. Bootstrap Kubernetes

```bash
cd ../../../ansible
ansible-galaxy collection install -r requirements.yml
ansible-playbook -i inventories/dev/hosts.ini playbooks/site.yml
```

## 5. Deploy the application

```bash
helm upgrade --install ecommerce helm/ecommerce \
  --namespace ecommerce --create-namespace \
  -f helm/ecommerce/values-dev.yaml
```

## 6. Tear down

```bash
helm uninstall ecommerce -n ecommerce
cd terraform/environments/dev
terraform destroy -var-file=dev.tfvars
```
