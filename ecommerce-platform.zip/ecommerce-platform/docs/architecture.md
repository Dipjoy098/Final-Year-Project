# Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│                         AWS Landing Zone                         │
│       (Organizations, Control Tower, IAM, KMS, Secrets Mgr)      │
└──────────────────────────────────────────────────────────────────┘
                              │
┌─────────────────────────────▼───────────────────────────────────┐
│                       Terraform Modules                         │
│   network · eks · rds · ecr · iam (IRSA) · observability        │
└─────────────────────────────┬───────────────────────────────────┘
                              │
┌─────────────────────────────▼───────────────────────────────────┐
│                     Ansible (bootstrap only)                    │
│  bastion · node-hardening · observability-agent · k8s-bootstrap │
└─────────────────────────────┬───────────────────────────────────┘
                              │
┌─────────────────────────────▼───────────────────────────────────┐
│                   Kubernetes Workloads (EKS)                    │
│      frontend · catalog · cart · order · payment   (Helm)       │
└─────────────────────────────┬───────────────────────────────────┘
                              │
┌─────────────────────────────▼───────────────────────────────────┐
│                       Observability Stack                       │
│  kube-prometheus-stack · Loki · Promtail · CloudWatch · OTel    │
└─────────────────────────────────────────────────────────────────┘
```

## Traffic flow

1. User hits CloudFront (or local kind ingress) → ingress-nginx → `frontend`.
2. `frontend` fans out to `catalog`, `cart`, `order`, `payment` over ClusterIP.
3. `order` and `cart` persist to PostgreSQL on RDS in production.
4. Every service exports `/metrics` and emits structured JSON logs.

## Environments

| Env     | Cluster          | RDS         | Public API | Notes                    |
| ------- | ---------------- | ----------- | ---------- | ------------------------ |
| local   | kind             | none        | localhost  | Single-node Docker.      |
| dev     | ecommerce-dev    | t3.medium   | yes        | Public EKS endpoint.     |
| staging | ecommerce-staging| t3.medium   | yes        | Pre-prod gating.         |
| prod    | ecommerce-prod   | m5.large MAZ| no         | Private endpoint, DR.    |
