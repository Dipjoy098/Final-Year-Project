# Architecture

Self-managed (no-cloud) deployment stack.

```
┌──────────────────────────────────────────────────────────────────┐
│                     Terraform  (larstobi/multipass)               │
│   Creates / deletes Ubuntu VMs on the host and emits the Ansible  │
│   inventory + SSH key   (server + N agents)                       │
└─────────────────────────────┬────────────────────────────────────┘
                              │  hosts.ini
┌─────────────────────────────▼────────────────────────────────────┐
│                          Ansible                                  │
│  node-hardening · observability-agent · k3s-server · k3s-agent    │
│  k8s-bootstrap  · app-deploy (deploy / rollout / rollback)        │
└─────────────────────────────┬────────────────────────────────────┘
                              │  installs
┌─────────────────────────────▼────────────────────────────────────┐
│                   Kubernetes workloads (k3s)                      │
│    frontend · catalog · cart · order · payment    (Helm chart)    │
│    Traefik ingress (bundled with k3s)                             │
└─────────────────────────────┬────────────────────────────────────┘
                              │  scraped by
┌─────────────────────────────▼────────────────────────────────────┐
│                      Observability stack                          │
│   kube-prometheus-stack · Loki · Promtail · node-exporter         │
└───────────────────────────────────────────────────────────────────┘

           Jenkins  ──►  test ─ build ─ scan ─ push ─ (ansible) deploy
```

## Traffic flow

1. User hits Traefik ingress → `frontend`.
2. `frontend` fans out to `catalog`, `cart`, `order`, `payment` over ClusterIP.
3. `order` and `cart` keep state in-memory (a PostgreSQL StatefulSet is the
   natural next step; the AWS path used RDS — see `archive/`).
4. Every service exports `/metrics` and emits structured JSON logs.

## Nodes

| Role       | Group (inventory) | Provisioned by | Configured by      |
| ---------- | ----------------- | -------------- | ------------------ |
| server     | `k3s_server`      | Terraform VM   | `k3s-server` role  |
| agent(s)   | `k3s_agents`      | Terraform VM   | `k3s-agent` role   |

## Lifecycle ownership

- **Create / delete instances** → Terraform (`make infra-up` / `infra-down`).
- **Install / configure cluster** → Ansible (`make cluster`).
- **Deploy / upgrade / rollback app** → Ansible playbooks (`make deploy` /
  `rollout` / `rollback`), invoked by Jenkins in CI/CD.

## Relationship to the AWS reference

`archive/aws-reference/` holds the original managed-cloud design (EKS node
groups, RDS Multi-AZ, ECR, IRSA, VPC). The mapping to this stack:

| AWS reference     | Self-managed equivalent          |
| ----------------- | -------------------------------- |
| EKS node group    | Multipass VMs + k3s              |
| ECR               | any registry (`localhost:5000`)  |
| RDS               | (future) in-cluster PostgreSQL   |
| Secrets Manager   | ansible-vault → k8s Secret       |
| GitHub Actions    | Jenkins pipeline                 |
