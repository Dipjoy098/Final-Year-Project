# loadtest

k6 scripts implementing the three traffic profiles described in the report.

| Script           | Profile          | VUs        | Duration                     |
| ---------------- | ---------------- | ---------- | ---------------------------- |
| `baseline.js`    | Browse           | 100        | 10 min steady                |
| `checkout.js`    | Cart + checkout  | 250        | 30 min steady                |
| `flash_sale.js`  | Flash sale       | 50 → 3000  | 5 min ramp + 15 min peak     |

```bash
BASE_URL=http://localhost:8080 k6 run loadtest/k6/baseline.js
```
