import http from "k6/http";
import { sleep, check } from "k6";

export const options = {
  vus: 250,
  duration: "30m",
  thresholds: {
    http_req_failed: ["rate<0.02"],
    http_req_duration: ["p(95)<800"],
  },
};

const BASE = __ENV.BASE_URL || "http://localhost:8080";

export default function () {
  const userId = `user-${__VU}`;

  const cart = http.post(
    `${BASE}/api/cart/${userId}/items`,
    JSON.stringify({ productId: "p-001", quantity: 1 }),
    { headers: { "content-type": "application/json" } },
  );
  check(cart, { "add 201": (r) => r.status === 201 });

  const checkout = http.post(
    `${BASE}/api/orders`,
    JSON.stringify({
      userId,
      items: [{ productId: "p-001", quantity: 1, price: 19.99 }],
      total: 19.99,
    }),
    { headers: { "content-type": "application/json" } },
  );
  check(checkout, { "checkout ok": (r) => r.status === 201 || r.status === 502 });

  sleep(Math.random() * 5 + 2);
}
