import http from "k6/http";
import { sleep, check } from "k6";

export const options = {
  scenarios: {
    flash: {
      executor: "ramping-vus",
      startVUs: 50,
      stages: [
        { duration: "5m",  target: 3000 },
        { duration: "15m", target: 3000 },
        { duration: "3m",  target: 0 },
      ],
      gracefulRampDown: "30s",
    },
  },
  thresholds: {
    http_req_failed: ["rate<0.05"],
    http_req_duration: ["p(95)<1500"],
  },
};

const BASE = __ENV.BASE_URL || "http://localhost:8080";

export default function () {
  const product = `p-00${(__ITER % 5) + 1}`;
  const list = http.get(`${BASE}/api/products`);
  check(list, { "list ok": (r) => r.status === 200 });

  const userId = `flash-${__VU}-${__ITER}`;
  http.post(
    `${BASE}/api/cart/${userId}/items`,
    JSON.stringify({ productId: product, quantity: 1 }),
    { headers: { "content-type": "application/json" } },
  );

  http.post(
    `${BASE}/api/orders`,
    JSON.stringify({
      userId,
      items: [{ productId: product, quantity: 1, price: 19.99 }],
      total: 19.99,
    }),
    { headers: { "content-type": "application/json" } },
  );

  sleep(Math.random() * 2);
}
