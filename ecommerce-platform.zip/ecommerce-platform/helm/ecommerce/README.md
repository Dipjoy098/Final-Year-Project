# helm/ecommerce

Single Helm chart that templates **all** microservices via the `services` list
in `values.yaml`. Adding a new service is one block in the values file plus a
Dockerfile under `services/<name>/`.

Per-environment overrides live in `values-{local,dev,staging,prod}.yaml`.

## Local

```bash
helm upgrade --install ecommerce . -n ecommerce --create-namespace -f values-local.yaml
```
