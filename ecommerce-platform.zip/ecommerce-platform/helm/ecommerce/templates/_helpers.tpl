{{/*
Common labels and selectors.
*/}}

{{- define "ecommerce.labels" -}}
app.kubernetes.io/name: {{ .svc.name }}
app.kubernetes.io/instance: {{ $.Release.Name }}
app.kubernetes.io/managed-by: {{ $.Release.Service }}
app.kubernetes.io/part-of: ecommerce
{{- end }}

{{- define "ecommerce.selector" -}}
app.kubernetes.io/name: {{ .svc.name }}
app.kubernetes.io/instance: {{ $.Release.Name }}
{{- end }}

{{- define "ecommerce.image" -}}
{{- $reg := .global.imageRegistry | default "" -}}
{{- printf "%s%s:%s" $reg .svc.image (.global.imageTag | toString) -}}
{{- end }}
