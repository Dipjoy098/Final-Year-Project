# archive/aws-reference

The original AWS-targeted implementation of this platform (Amazon EKS, RDS,
ECR, IRSA, and a VPC network module) lives here, preserved as the "cloud
target" reference for the MajorProject report.

The active deployment path no longer requires AWS. Instead:

- **Terraform** provisions local Ubuntu VMs with the **Multipass** provider
  (`terraform/` at the repo root).
- **Ansible** installs a self-managed **k3s** Kubernetes cluster on those VMs
  and handles all upgrades / rollouts.
- **Jenkins** runs the CI/CD pipeline.

Nothing in this folder is wired into the current pipeline; it is kept for
comparison and future migration back to a managed cloud.
