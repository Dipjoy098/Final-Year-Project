terraform {
  required_version = ">= 1.7.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.40"
    }
  }

  backend "s3" {
    bucket         = "ecommerce-platform-tfstate"
    key            = "environments/prod/terraform.tfstate"
    region         = "us-east-1"
    dynamodb_table = "ecommerce-platform-tflock"
    encrypt        = true
  }
}

provider "aws" {
  region = var.region
  default_tags {
    tags = {
      Project     = "ecommerce-platform"
      Environment = "prod"
      ManagedBy   = "terraform"
    }
  }
}

data "aws_caller_identity" "current" {}

locals {
  cluster_name = "ecommerce-prod"
}

module "network" {
  source       = "../../modules/network"
  environment  = "prod"
  cluster_name = local.cluster_name
  vpc_cidr     = "10.30.0.0/16"
  az_count     = 3
}

module "ecr" {
  source      = "../../modules/ecr"
  environment = "prod"
}

module "eks" {
  source       = "../../modules/eks"
  environment  = "prod"
  cluster_name = local.cluster_name
  subnet_ids   = module.network.private_subnet_ids

  endpoint_public_access = false

  node_groups = {
    general = {
      desired_size   = 3
      min_size       = 3
      max_size       = 12
      instance_types = ["m5.xlarge"]
      capacity_type  = "ON_DEMAND"
    }
    spot = {
      desired_size   = 0
      min_size       = 0
      max_size       = 6
      instance_types = ["m5.xlarge", "m5a.xlarge", "m5n.xlarge"]
      capacity_type  = "SPOT"
      labels         = { "workload" = "burst" }
    }
  }
}

module "rds" {
  source                     = "../../modules/rds"
  environment                = "prod"
  vpc_id                     = module.network.vpc_id
  subnet_ids                 = module.network.private_subnet_ids
  allowed_security_group_ids = []
  instance_class             = "db.m5.large"
  allocated_storage          = 200
  multi_az                   = true
  deletion_protection        = true
  backup_retention_days      = 14
}

module "observability" {
  source             = "../../modules/observability"
  environment        = "prod"
  cluster_name       = local.cluster_name
  account_id         = data.aws_caller_identity.current.account_id
  log_retention_days = 90
}
