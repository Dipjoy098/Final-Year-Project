variable "region" {
  type    = string
  default = "us-east-1"
}

variable "developer_cidrs" {
  description = "Office / VPN CIDRs allowed to reach the EKS API."
  type        = list(string)
  default     = []
}
