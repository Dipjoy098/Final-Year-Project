terraform {
  required_version = ">= 1.7.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.40"
    }
  }

  backend "s3" {
    bucket         = "ecommerce-platform-tfstate"
    key            = "environments/dev/terraform.tfstate"
    region         = "us-east-1"
    dynamodb_table = "ecommerce-platform-tflock"
    encrypt        = true
  }
}

provider "aws" {
  region = var.region
  default_tags {
    tags = {
      Project     = "ecommerce-platform"
      Environment = "dev"
      ManagedBy   = "terraform"
    }
  }
}

data "aws_caller_identity" "current" {}

module "network" {
  source       = "../../modules/network"
  environment  = "dev"
  cluster_name = local.cluster_name
  vpc_cidr     = "10.10.0.0/16"
  az_count     = 2
}

module "ecr" {
  source      = "../../modules/ecr"
  environment = "dev"
}

module "eks" {
  source       = "../../modules/eks"
  environment  = "dev"
  cluster_name = local.cluster_name
  subnet_ids   = module.network.private_subnet_ids

  endpoint_public_access = true
  public_access_cidrs    = var.developer_cidrs

  node_groups = {
    general = {
      desired_size   = 2
      min_size       = 1
      max_size       = 4
      instance_types = ["t3.medium"]
      capacity_type  = "ON_DEMAND"
    }
  }
}

module "rds" {
  source                     = "../../modules/rds"
  environment                = "dev"
  vpc_id                     = module.network.vpc_id
  subnet_ids                 = module.network.private_subnet_ids
  allowed_security_group_ids = []
  instance_class             = "db.t3.medium"
  multi_az                   = false
  deletion_protection        = false
}

module "observability" {
  source       = "../../modules/observability"
  environment  = "dev"
  cluster_name = local.cluster_name
  account_id   = data.aws_caller_identity.current.account_id
}

locals {
  cluster_name = "ecommerce-dev"
}
