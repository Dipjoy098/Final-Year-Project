output "server_ip" {
  description = "IPv4 of the k3s server node."
  value       = data.external.server_ip.result.ipv4
}

output "agent_ips" {
  description = "IPv4 of each k3s agent node."
  value       = { for name, d in data.external.agent_ip : name => d.result.ipv4 }
}

output "ssh_private_key_file" {
  description = "Path to the generated SSH private key Ansible uses."
  value       = abspath(local_sensitive_file.private_key.filename)
}

output "inventory_file" {
  description = "Path to the generated Ansible inventory."
  value       = abspath(local_file.inventory.filename)
}
