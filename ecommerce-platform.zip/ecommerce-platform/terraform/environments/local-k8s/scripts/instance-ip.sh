#!/bin/bash
# Emit {"ipv4": "<addr>"} for a Multipass instance, as required by the
# Terraform external data source. Retries while the VM finishes booting.
set -euo pipefail

NAME="${1:?instance name required}"

ip=""
for _ in $(seq 1 30); do
  ip="$(multipass info "$NAME" --format csv 2>/dev/null \
        | awk -F, 'NR==2 {print $3}' \
        | awk '{print $1}')"
  if [[ -n "$ip" && "$ip" != "--" ]]; then
    break
  fi
  sleep 2
done

if [[ -z "$ip" || "$ip" == "--" ]]; then
  echo "could not resolve IPv4 for instance $NAME" >&2
  exit 1
fi

printf '{"ipv4": "%s"}\n' "$ip"
