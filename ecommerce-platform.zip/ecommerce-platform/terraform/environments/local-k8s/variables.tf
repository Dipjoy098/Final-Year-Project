variable "cluster_name" {
  description = "Logical cluster name; prefixes each VM."
  type        = string
  default     = "ecommerce"
}

variable "agent_count" {
  description = "Number of k3s agent (worker) nodes to create alongside the single server."
  type        = number
  default     = 1

  validation {
    condition     = var.agent_count >= 0 && var.agent_count <= 5
    error_message = "agent_count must be between 0 and 5."
  }
}

variable "image" {
  description = "Ubuntu image alias for all nodes."
  type        = string
  default     = "22.04"
}

variable "server_cpus" {
  description = "vCPUs for the k3s server node."
  type        = number
  default     = 2
}

variable "server_memory" {
  description = "Memory for the k3s server node."
  type        = string
  default     = "3G"
}

variable "server_disk" {
  description = "Disk for the k3s server node."
  type        = string
  default     = "12G"
}

variable "agent_cpus" {
  description = "vCPUs per k3s agent node."
  type        = number
  default     = 2
}

variable "agent_memory" {
  description = "Memory per k3s agent node."
  type        = string
  default     = "2G"
}

variable "agent_disk" {
  description = "Disk per k3s agent node."
  type        = string
  default     = "10G"
}

variable "ssh_user" {
  description = "Default Ubuntu SSH user Ansible connects as."
  type        = string
  default     = "ubuntu"
}
