locals {
  server_name = "${var.cluster_name}-server"
  agent_names = [for i in range(var.agent_count) : "${var.cluster_name}-agent-${i + 1}"]
}

# --- SSH key Ansible will use to reach every VM ---------------------------
resource "tls_private_key" "ansible" {
  algorithm = "ED25519"
}

resource "local_sensitive_file" "private_key" {
  content         = tls_private_key.ansible.private_key_openssh
  filename        = "${path.module}/.ssh/id_ed25519"
  file_permission = "0600"
}

resource "local_file" "public_key" {
  content         = tls_private_key.ansible.public_key_openssh
  filename        = "${path.module}/.ssh/id_ed25519.pub"
  file_permission = "0644"
}

# --- cloud-init: install the SSH key + Python for Ansible -----------------
resource "local_file" "cloudinit" {
  filename = "${path.module}/.ssh/cloud-init.yaml"
  content = templatefile("${path.module}/templates/cloud-init.yaml.tftpl", {
    ssh_user       = var.ssh_user
    ssh_public_key = trimspace(tls_private_key.ansible.public_key_openssh)
  })
}

# --- VMs (Terraform owns create/delete) -----------------------------------
module "server" {
  source         = "../../modules/multipass-node"
  name           = local.server_name
  cpus           = var.server_cpus
  memory         = var.server_memory
  disk           = var.server_disk
  image          = var.image
  cloudinit_file = local_file.cloudinit.filename
}

module "agents" {
  source   = "../../modules/multipass-node"
  for_each = toset(local.agent_names)

  name           = each.value
  cpus           = var.agent_cpus
  memory         = var.agent_memory
  disk           = var.agent_disk
  image          = var.image
  cloudinit_file = local_file.cloudinit.filename
}

# --- Resolve IPs assigned by Multipass at boot ----------------------------
# Multipass assigns the IP dynamically, so we read it back after the VM is up.
data "external" "server_ip" {
  program    = ["bash", "${path.module}/scripts/instance-ip.sh", module.server.name]
  depends_on = [module.server]
}

data "external" "agent_ip" {
  for_each   = module.agents
  program    = ["bash", "${path.module}/scripts/instance-ip.sh", each.value.name]
  depends_on = [module.agents]
}

# --- Emit the Ansible inventory -------------------------------------------
resource "local_file" "inventory" {
  filename = "${path.root}/../../../ansible/inventories/local-k8s/hosts.ini"
  content = templatefile("${path.module}/templates/inventory.ini.tftpl", {
    server_name = local.server_name
    server_ip   = data.external.server_ip.result.ipv4
    agents = [
      for name, d in data.external.agent_ip : {
        name = name
        ip   = d.result.ipv4
      }
    ]
    ssh_user        = var.ssh_user
    private_key     = abspath(local_sensitive_file.private_key.filename)
    environment     = "local-k8s"
  })
}
