cluster_name  = "ecommerce"
agent_count   = 1
image         = "22.04"

server_cpus   = 2
server_memory = "3G"
server_disk   = "12G"

agent_cpus    = 2
agent_memory  = "2G"
agent_disk    = "10G"

ssh_user      = "ubuntu"
