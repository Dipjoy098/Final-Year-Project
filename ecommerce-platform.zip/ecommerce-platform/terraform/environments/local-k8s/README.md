# environments/local-k8s

Terraform root module that stands up the VMs for a self-managed **k3s** cluster
using **Multipass** — the AWS-free replacement for `environments/dev` (EKS).

What `terraform apply` does:

1. Generates an ED25519 SSH keypair (`.ssh/id_ed25519`) and a cloud-init file.
2. Launches `<cluster_name>-server` and `<cluster_name>-agent-N` Ubuntu VMs
   (Terraform owns their create/delete lifecycle).
3. Resolves each VM's IP and writes
   `ansible/inventories/local-k8s/hosts.ini`.

Ansible then installs k3s on these hosts (see `ansible/playbooks/site.yml`).

## Prerequisites

- [Multipass](https://multipass.run/) installed (`brew install --cask multipass`).
- Terraform 1.7+.

## Usage

```bash
cd terraform/environments/local-k8s
terraform init
terraform apply -var-file=local-k8s.tfvars

# tear the VMs down (deletes the instances)
terraform destroy -var-file=local-k8s.tfvars
```

After apply, the generated inventory and SSH key are ready for:

```bash
cd ../../../ansible
ansible-playbook -i inventories/local-k8s/hosts.ini playbooks/site.yml
```

> `.ssh/` and `*.tfstate*` are gitignored — they contain the private key and
> resolved host data.
