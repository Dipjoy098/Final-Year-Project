output "server" {
  value       = module.server.name
  description = "Server node container name."
}

output "agents" {
  value       = [for m in module.agents : m.name]
  description = "Agent node container names."
}

output "node_count" {
  value       = 1 + length(module.agents)
  description = "Total number of node containers Terraform is managing."
}
