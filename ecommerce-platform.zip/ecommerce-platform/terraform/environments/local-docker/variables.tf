variable "cluster_name" {
  type        = string
  default     = "ecommerce-demo"
  description = "Name prefix for the node containers."
}

variable "agent_count" {
  type        = number
  default     = 1
  description = "Number of agent nodes. Change this and re-apply to scale up/down."
}

variable "node_image" {
  type        = string
  default     = "alpine:3.20"
  description = "Image used for each node container."
}
