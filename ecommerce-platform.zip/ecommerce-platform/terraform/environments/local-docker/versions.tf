terraform {
  required_version = ">= 1.5"

  required_providers {
    docker = {
      source  = "kreuzwerker/docker"
      version = "~> 3.0"
    }
  }
}

# Talks to whatever Docker daemon the environment points at (Docker Desktop,
# Colima, or a remote host) via the standard DOCKER_HOST variable. No path is
# hardcoded, so this works on any machine.
provider "docker" {}
