locals {
  server_name = "${var.cluster_name}-server"
  agent_names = [for i in range(var.agent_count) : "${var.cluster_name}-agent-${i + 1}"]
}

# Pull the node image once (idempotent).
resource "docker_image" "node" {
  name = var.node_image
}

# --- Server node (always exactly one) -------------------------------------
module "server" {
  source  = "../../modules/docker-node"
  name    = local.server_name
  image   = docker_image.node.image_id
  role    = "server"
  cluster = var.cluster_name
}

# --- Agent nodes (count driven by var.agent_count) ------------------------
# Change agent_count and re-run `terraform apply` to scale up or down.
# Terraform diffs the desired set against state and creates/destroys the delta.
module "agents" {
  source   = "../../modules/docker-node"
  for_each = toset(local.agent_names)

  name    = each.value
  image   = docker_image.node.image_id
  role    = "agent"
  cluster = var.cluster_name
}
