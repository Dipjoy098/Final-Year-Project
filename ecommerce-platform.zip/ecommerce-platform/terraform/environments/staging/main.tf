terraform {
  required_version = ">= 1.7.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.40"
    }
  }

  backend "s3" {
    bucket         = "ecommerce-platform-tfstate"
    key            = "environments/staging/terraform.tfstate"
    region         = "us-east-1"
    dynamodb_table = "ecommerce-platform-tflock"
    encrypt        = true
  }
}

provider "aws" {
  region = var.region
  default_tags {
    tags = {
      Project     = "ecommerce-platform"
      Environment = "staging"
      ManagedBy   = "terraform"
    }
  }
}

data "aws_caller_identity" "current" {}

locals {
  cluster_name = "ecommerce-staging"
}

module "network" {
  source       = "../../modules/network"
  environment  = "staging"
  cluster_name = local.cluster_name
  vpc_cidr     = "10.20.0.0/16"
  az_count     = 3
}

module "ecr" {
  source      = "../../modules/ecr"
  environment = "staging"
}

module "eks" {
  source       = "../../modules/eks"
  environment  = "staging"
  cluster_name = local.cluster_name
  subnet_ids   = module.network.private_subnet_ids

  node_groups = {
    general = {
      desired_size   = 3
      min_size       = 3
      max_size       = 8
      instance_types = ["m5.large"]
      capacity_type  = "ON_DEMAND"
    }
  }
}

module "rds" {
  source                     = "../../modules/rds"
  environment                = "staging"
  vpc_id                     = module.network.vpc_id
  subnet_ids                 = module.network.private_subnet_ids
  allowed_security_group_ids = []
  instance_class             = "db.t3.medium"
  multi_az                   = false
  deletion_protection        = true
}

module "observability" {
  source       = "../../modules/observability"
  environment  = "staging"
  cluster_name = local.cluster_name
  account_id   = data.aws_caller_identity.current.account_id
}
