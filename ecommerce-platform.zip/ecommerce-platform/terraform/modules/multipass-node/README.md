# multipass-node

Provisions a single Ubuntu VM via [Multipass](https://multipass.run/), the
non-AWS replacement for the archived `eks` node groups. Terraform owns the
instance lifecycle: `terraform apply` launches the VM, `terraform destroy`
deletes it.

The instance is seeded with a cloud-init file so that the SSH public key is
installed and Python is present for Ansible to connect over SSH.

## Inputs

| Name             | Description                          | Default |
| ---------------- | ------------------------------------ | ------- |
| `name`           | Instance name                        | —       |
| `cpus`           | vCPUs (1–8)                          | `2`     |
| `memory`         | Memory (e.g. `2G`)                   | `2G`    |
| `disk`           | Disk (e.g. `10G`)                    | `10G`   |
| `image`          | Ubuntu alias (`22.04`, `24.04`)      | `22.04` |
| `cloudinit_file` | Path to cloud-init YAML              | —       |

## Outputs

| Name   | Description               |
| ------ | ------------------------- |
| `name` | Created instance name     |

The instance IP is resolved at the environment level (via `multipass info`)
because Multipass assigns it at boot.
