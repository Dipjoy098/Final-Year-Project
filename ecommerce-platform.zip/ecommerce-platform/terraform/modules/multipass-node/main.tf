terraform {
  required_providers {
    multipass = {
      source  = "larstobi/multipass"
      version = "~> 1.4"
    }
  }
}

# One Multipass VM. Creating/destroying this resource creates/deletes a real
# Ubuntu instance on the host — the Terraform-owned lifecycle required by the
# project (equivalent to an EC2 instance in the archived AWS path).
resource "multipass_instance" "this" {
  name           = var.name
  cpus           = var.cpus
  memory         = var.memory
  disk           = var.disk
  image          = var.image
  cloudinit_file = var.cloudinit_file
}
