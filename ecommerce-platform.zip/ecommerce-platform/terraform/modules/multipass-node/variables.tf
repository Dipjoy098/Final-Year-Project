variable "name" {
  description = "Multipass instance name."
  type        = string
}

variable "cpus" {
  description = "Number of vCPUs for the instance."
  type        = number
  default     = 2

  validation {
    condition     = var.cpus >= 1 && var.cpus <= 8
    error_message = "cpus must be between 1 and 8."
  }
}

variable "memory" {
  description = "Memory for the instance (e.g. 2G, 4096M)."
  type        = string
  default     = "2G"
}

variable "disk" {
  description = "Disk size for the instance (e.g. 10G)."
  type        = string
  default     = "10G"
}

variable "image" {
  description = "Ubuntu image alias to launch (e.g. 22.04, 24.04)."
  type        = string
  default     = "22.04"
}

variable "cloudinit_file" {
  description = "Path to a cloud-init YAML file used to seed the instance (SSH key, packages)."
  type        = string
}
