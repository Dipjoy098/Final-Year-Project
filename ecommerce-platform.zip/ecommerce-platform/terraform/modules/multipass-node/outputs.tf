output "name" {
  description = "Name of the created Multipass instance."
  value       = multipass_instance.this.name
}
