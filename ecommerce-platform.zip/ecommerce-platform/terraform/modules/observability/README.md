# observability module

Creates the AWS-side resources used by the in-cluster observability stack:

- Amazon Managed Service for Prometheus (AMP) workspace for long-term metrics
- CloudWatch log groups for application logs and EKS control plane logs
- S3 bucket for log archives, encrypted, versioned, and locked down
