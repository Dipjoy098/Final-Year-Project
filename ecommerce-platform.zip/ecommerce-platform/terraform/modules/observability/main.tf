terraform {
  required_version = ">= 1.7.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.40"
    }
  }
}

locals {
  common_tags = merge(
    {
      "Project"     = "ecommerce-platform"
      "Environment" = var.environment
      "ManagedBy"   = "terraform"
    },
    var.tags,
  )
}

resource "aws_prometheus_workspace" "this" {
  alias = "${var.environment}-ecommerce"
  tags  = local.common_tags
}

resource "aws_cloudwatch_log_group" "application" {
  name              = "/ecommerce/${var.environment}/application"
  retention_in_days = var.log_retention_days
  kms_key_id        = var.logs_kms_key_arn
  tags              = local.common_tags
}

resource "aws_cloudwatch_log_group" "control_plane" {
  name              = "/aws/eks/${var.cluster_name}/cluster"
  retention_in_days = var.log_retention_days
  kms_key_id        = var.logs_kms_key_arn
  tags              = local.common_tags
}

resource "aws_s3_bucket" "logs_archive" {
  bucket        = "ecommerce-${var.environment}-logs-archive-${var.account_id}"
  force_destroy = false
  tags          = local.common_tags
}

resource "aws_s3_bucket_versioning" "logs_archive" {
  bucket = aws_s3_bucket.logs_archive.id
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "logs_archive" {
  bucket = aws_s3_bucket.logs_archive.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

resource "aws_s3_bucket_public_access_block" "logs_archive" {
  bucket                  = aws_s3_bucket.logs_archive.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}
