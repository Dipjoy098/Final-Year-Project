output "amp_workspace_id" {
  value = aws_prometheus_workspace.this.id
}

output "amp_workspace_endpoint" {
  value = aws_prometheus_workspace.this.prometheus_endpoint
}

output "logs_archive_bucket" {
  value = aws_s3_bucket.logs_archive.bucket
}

output "application_log_group" {
  value = aws_cloudwatch_log_group.application.name
}
