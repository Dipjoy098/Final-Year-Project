variable "environment" {
  type = string
}

variable "cluster_name" {
  type = string
}

variable "account_id" {
  type        = string
  description = "AWS account ID, used to make the S3 bucket name globally unique."
}

variable "log_retention_days" {
  type    = number
  default = 30
}

variable "logs_kms_key_arn" {
  type    = string
  default = null
}

variable "tags" {
  type    = map(string)
  default = {}
}
