output "endpoint" {
  description = "Endpoint hostname of the database."
  value       = aws_db_instance.this.address
}

output "port" {
  value = aws_db_instance.this.port
}

output "credentials_secret_arn" {
  value       = aws_secretsmanager_secret.db.arn
  description = "ARN of the Secrets Manager secret with master credentials."
}

output "security_group_id" {
  value = aws_security_group.db.id
}
