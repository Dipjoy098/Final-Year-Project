terraform {
  required_version = ">= 1.7.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.40"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.6"
    }
  }
}

locals {
  common_tags = merge(
    {
      "Project"     = "ecommerce-platform"
      "Environment" = var.environment
      "ManagedBy"   = "terraform"
    },
    var.tags,
  )
}

resource "random_password" "master" {
  length  = 32
  special = false
}

resource "aws_secretsmanager_secret" "db" {
  name        = "${var.environment}/${var.identifier}/credentials"
  description = "RDS master credentials for ${var.identifier}"
  tags        = local.common_tags
}

resource "aws_secretsmanager_secret_version" "db" {
  secret_id = aws_secretsmanager_secret.db.id
  secret_string = jsonencode({
    username = var.master_username
    password = random_password.master.result
    host     = aws_db_instance.this.address
    port     = aws_db_instance.this.port
    dbname   = aws_db_instance.this.db_name
  })
}

resource "aws_db_subnet_group" "this" {
  name       = "${var.environment}-${var.identifier}"
  subnet_ids = var.subnet_ids
  tags       = local.common_tags
}

resource "aws_security_group" "db" {
  name        = "${var.environment}-${var.identifier}-db"
  description = "Allow PostgreSQL traffic from cluster security groups"
  vpc_id      = var.vpc_id

  ingress {
    from_port       = 5432
    to_port         = 5432
    protocol        = "tcp"
    security_groups = var.allowed_security_group_ids
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = local.common_tags
}

resource "aws_db_instance" "this" {
  identifier = "${var.environment}-${var.identifier}"

  engine            = "postgres"
  engine_version    = var.engine_version
  instance_class    = var.instance_class
  allocated_storage = var.allocated_storage
  storage_encrypted = true
  storage_type      = "gp3"

  db_name  = var.db_name
  username = var.master_username
  password = random_password.master.result

  multi_az               = var.multi_az
  publicly_accessible    = false
  db_subnet_group_name   = aws_db_subnet_group.this.name
  vpc_security_group_ids = [aws_security_group.db.id]

  backup_retention_period   = var.backup_retention_days
  delete_automated_backups  = false
  copy_tags_to_snapshot     = true
  deletion_protection       = var.deletion_protection
  skip_final_snapshot       = !var.deletion_protection
  final_snapshot_identifier = var.deletion_protection ? "${var.environment}-${var.identifier}-final" : null

  performance_insights_enabled = true
  monitoring_interval          = 60

  tags = local.common_tags
}
