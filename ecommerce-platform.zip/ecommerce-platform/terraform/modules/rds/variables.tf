variable "environment" {
  type = string
}

variable "identifier" {
  description = "Logical identifier for the database, used in resource names."
  type        = string
  default     = "ecommerce"
}

variable "vpc_id" {
  type = string
}

variable "subnet_ids" {
  description = "Private subnets in which to place the DB."
  type        = list(string)
}

variable "allowed_security_group_ids" {
  description = "Security groups permitted to reach the DB on 5432/tcp."
  type        = list(string)
}

variable "engine_version" {
  type    = string
  default = "16.2"
}

variable "instance_class" {
  type    = string
  default = "db.t3.medium"
}

variable "allocated_storage" {
  type    = number
  default = 50
}

variable "db_name" {
  type    = string
  default = "ecommerce"
}

variable "master_username" {
  type    = string
  default = "ecom_app"
}

variable "multi_az" {
  type    = bool
  default = false
}

variable "backup_retention_days" {
  type    = number
  default = 7
}

variable "deletion_protection" {
  type    = bool
  default = true
}

variable "tags" {
  type    = map(string)
  default = {}
}
