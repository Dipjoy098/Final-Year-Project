output "name" {
  value       = docker_container.this.name
  description = "Container name of the node."
}

output "id" {
  value       = docker_container.this.id
  description = "Container ID of the node."
}
