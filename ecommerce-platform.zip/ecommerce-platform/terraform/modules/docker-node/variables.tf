variable "name" {
  type        = string
  description = "Container name for this node."
}

variable "image" {
  type        = string
  description = "Image to run as the node."
}

variable "role" {
  type        = string
  description = "Node role label (server or agent)."
}

variable "cluster" {
  type        = string
  description = "Cluster name label."
}
