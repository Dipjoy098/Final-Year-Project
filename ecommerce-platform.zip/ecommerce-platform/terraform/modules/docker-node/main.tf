terraform {
  required_providers {
    docker = {
      source  = "kreuzwerker/docker"
      version = "~> 3.0"
    }
  }
}

# One container standing in for a cluster node. In the Multipass environment
# this is a full Ubuntu VM; here it is a lightweight container so the Terraform
# create / scale / destroy workflow can be demonstrated without sudo or a
# hypervisor. The scaling mechanism (a variable driving for_each) is identical.
resource "docker_container" "this" {
  name  = var.name
  image = var.image

  # Keep the container alive so it behaves like a long-lived "node".
  command = ["sleep", "infinity"]

  labels {
    label = "role"
    value = var.role
  }
  labels {
    label = "cluster"
    value = var.cluster
  }
}
