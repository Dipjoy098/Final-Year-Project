# network module

Creates a VPC with public and private subnets across multiple AZs, NAT gateways
per AZ for outbound traffic from private subnets, and a Gateway VPC endpoint
for Amazon S3.

Subnets are tagged for use with the AWS Load Balancer Controller and the
Kubernetes cluster autoscaler.

## Usage

```hcl
module "network" {
  source       = "../../modules/network"
  environment  = "dev"
  cluster_name = "ecommerce-dev"
  vpc_cidr     = "10.10.0.0/16"
  az_count     = 3
}
```
