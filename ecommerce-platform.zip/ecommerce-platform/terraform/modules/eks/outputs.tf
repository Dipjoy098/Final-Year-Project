output "cluster_name" {
  value       = aws_eks_cluster.this.name
  description = "Name of the EKS cluster."
}

output "cluster_endpoint" {
  value       = aws_eks_cluster.this.endpoint
  description = "EKS API endpoint."
}

output "cluster_ca_certificate" {
  value       = aws_eks_cluster.this.certificate_authority[0].data
  description = "Base64-encoded CA certificate for the cluster."
  sensitive   = true
}

output "oidc_provider_arn" {
  value       = aws_iam_openid_connect_provider.this.arn
  description = "ARN of the OIDC provider for IRSA."
}

output "oidc_provider_url" {
  value       = aws_iam_openid_connect_provider.this.url
  description = "URL of the OIDC provider for IRSA."
}

output "node_role_arn" {
  value       = aws_iam_role.node.arn
  description = "Worker-node IAM role ARN."
}
