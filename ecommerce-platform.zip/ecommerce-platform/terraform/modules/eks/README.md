# eks module

Provisions a managed Amazon EKS cluster with:

- KMS-encrypted Kubernetes secrets
- Control-plane logging on all log types
- Managed node groups (any number, defined as a map)
- An OIDC provider for IAM Roles for Service Accounts (IRSA)

## Example

```hcl
module "eks" {
  source       = "../../modules/eks"
  environment  = "staging"
  cluster_name = "ecommerce-staging"
  subnet_ids   = module.network.private_subnet_ids

  node_groups = {
    general = {
      desired_size   = 3
      min_size       = 3
      max_size       = 10
      instance_types = ["m5.large"]
      capacity_type  = "ON_DEMAND"
    }
    spot = {
      desired_size   = 0
      min_size       = 0
      max_size       = 6
      instance_types = ["m5.large", "m5a.large", "m5n.large"]
      capacity_type  = "SPOT"
      labels         = { "workload" = "burst" }
    }
  }
}
```
