variable "environment" {
  description = "Environment name."
  type        = string
}

variable "cluster_name" {
  description = "EKS cluster name."
  type        = string
}

variable "kubernetes_version" {
  description = "Kubernetes version for the EKS control plane."
  type        = string
  default     = "1.29"
}

variable "subnet_ids" {
  description = "Subnets in which to place the cluster ENIs and node groups."
  type        = list(string)
}

variable "endpoint_public_access" {
  description = "Whether the EKS API endpoint is reachable from the internet."
  type        = bool
  default     = false
}

variable "public_access_cidrs" {
  description = "Allowed CIDRs when endpoint_public_access is true."
  type        = list(string)
  default     = []
}

variable "node_groups" {
  description = "Map of managed node groups."
  type = map(object({
    desired_size   = number
    min_size       = number
    max_size       = number
    instance_types = list(string)
    capacity_type  = string
    labels         = optional(map(string), {})
    taints = optional(list(object({
      key    = string
      value  = string
      effect = string
    })), [])
  }))
}

variable "tags" {
  description = "Additional tags."
  type        = map(string)
  default     = {}
}
