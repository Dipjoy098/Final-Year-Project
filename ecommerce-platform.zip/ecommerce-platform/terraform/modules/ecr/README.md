# ecr module

Creates one Amazon ECR repository per microservice, with:

- Immutable image tags (forces explicit version bumps)
- Scan on push enabled
- KMS-encrypted storage
- A 30-image retention lifecycle policy
