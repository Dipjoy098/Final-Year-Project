variable "environment" {
  type = string
}

variable "repositories" {
  description = "List of repository names to create (without the environment prefix)."
  type        = list(string)
  default     = ["frontend", "catalog", "cart", "order", "payment"]
}

variable "tags" {
  type    = map(string)
  default = {}
}
