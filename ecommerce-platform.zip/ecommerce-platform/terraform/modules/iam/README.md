# iam (IRSA) module

Creates an IAM role that a Kubernetes service account can assume through the
EKS OIDC provider. Use one instance per service account that needs AWS access.
