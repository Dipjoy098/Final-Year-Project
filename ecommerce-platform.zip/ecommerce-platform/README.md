# E-Commerce Platform — Self-Managed Kubernetes Deployment

A containerized microservice e-commerce application with a **complete
infrastructure and CI/CD pipeline**, built to run **without any cloud account**:

- **Terraform** provisions the compute (local Ubuntu VMs via Multipass).
- **Ansible** installs a self-managed **k3s** Kubernetes cluster and drives all
  upgrades / rollouts.
- **Helm** packages the application.
- **Jenkins** runs the CI/CD pipeline (test → build → scan → push → deploy).
- **Prometheus / Grafana / Loki** provide observability.

> An earlier AWS (EKS/RDS/ECR) implementation is preserved under
> [`archive/aws-reference/`](archive/aws-reference/) for reference only — it is
> not needed to run this project.

---

## Table of contents

1. [Architecture at a glance](#architecture-at-a-glance)
2. [The five services](#the-five-services)
3. [Prerequisites](#prerequisites)
4. [How to run & test — three levels](#how-to-run--test--three-levels)
   - [Level 1 — App logic (no Docker, ~2 min)](#level-1--app-logic-no-docker-needed)
   - [Level 2 — Containers on local Kubernetes (kind)](#level-2--containers-on-local-kubernetes-kind)
   - [Level 3 — Full IaC pipeline (Terraform + Ansible + k3s)](#level-3--full-iac-pipeline-terraform--ansible--k3s)
5. [CI/CD with Jenkins](#cicd-with-jenkins)
6. [Repository layout](#repository-layout)
7. [Troubleshooting](#troubleshooting)

---

## Architecture at a glance

```
User ─► Ingress (Traefik) ─► frontend ─┬─► catalog
                                       ├─► cart
                                       ├─► order ─► payment
                                       └─► (metrics/logs ─► Prometheus/Loki)

Provisioning:  Terraform ─(creates VMs)─► Ansible ─(installs k3s + deploys)─► Helm
CI/CD:         Jenkins ─► test ─► build ─► scan ─► push ─► (Ansible) rollout
```

`frontend` is a Backend-for-Frontend that fans out to the other four services.
Placing an order calls `order` → `payment` → confirms the order. Every service
exposes `/healthz`, `/readyz`, and `/metrics`.

---

## The five services

| Service   | Port | Purpose                                             |
| --------- | ---- | --------------------------------------------------- |
| frontend  | 8080 | Storefront BFF; fans out to the others.             |
| catalog   | 8080 | Product catalog (in-memory).                        |
| cart      | 8080 | Per-user cart (in-memory).                          |
| order     | 8080 | Order state machine (PENDING → CONFIRMED).          |
| payment   | 8080 | Mock payment authorization (configurable failure).  |

Each is a small Node.js/Express app. They listen on the port given by the
`PORT` environment variable (default `8080`).

---

## Prerequisites

You do **not** need everything — install only what the level you want requires.

| Tool | Needed for | Install (macOS / Homebrew) |
| ---- | ---------- | -------------------------- |
| Node.js 20+ | Level 1, tests | `brew install node` |
| Docker | Levels 2 & 3 (build images) | Docker Desktop, or `brew install colima docker && colima start` |
| kind | Level 2 | `brew install kind` |
| Helm 3.14+ | Levels 2 & 3 | `brew install helm` |
| kubectl 1.29+ | Levels 2 & 3 | `brew install kubectl` |
| Terraform 1.7+ | Level 3 | `brew install terraform` |
| Ansible 9+ | Level 3 | `brew install ansible` |
| Multipass | Level 3 (VMs) | `brew install --cask multipass` |
| k6 | Load tests (optional) | `brew install k6` |

> **Linux:** the same tools are available via your package manager, `apt`, or
> the official install scripts. Multipass: `sudo snap install multipass`.

Check what you already have:

```bash
for t in node docker terraform ansible helm kubectl multipass kind; do
  printf "%-12s " "$t"
  command -v "$t" >/dev/null 2>&1 && echo "installed" || echo "MISSING"
done
```

---

## Quick start — one command

The fastest way to see the whole application running. These scripts install
every prerequisite, start Docker, build the images, deploy to a local
Kubernetes (kind) cluster, verify the checkout flow, and open the storefront.

**macOS:**

```bash
./scripts/setup-mac.sh
```

**Windows — Git Bash** (bare PC, only Git for Windows installed):

```bash
./scripts/setup-windows-gitbash.sh
```

This downloads Node, kubectl, kind and helm into a user-local folder (no admin,
no winget/choco/scoop needed), installs/starts Docker Desktop, then builds and
runs everything. Re-run it after finishing the Docker Desktop install.

**Windows — PowerShell** (if you prefer, and have `winget`):

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\setup-windows.ps1
```

All are safe to re-run — they wipe and rebuild from scratch. On Windows this
needs **Docker Desktop in Linux-containers mode** (the default).

Prefer to go step by step, or don't want the auto-install? Use the three levels
below.

---

## How to run & test — three levels

Start at Level 1 (fastest, proves the app works) and go as deep as your tools
allow. **Levels are independent** — you can stop at any one.

### Level 1 — App logic (no Docker needed)

Proves the microservices and the end-to-end checkout flow work. Takes ~2 min.
Only Node.js is required.

**Run the unit tests:**

```bash
make test-services
```

**Run the end-to-end smoke test** — one command starts all five services,
exercises the full `browse → cart → order → payment → confirm` flow, prints the
results, and shuts everything down automatically:

```bash
make smoke-test
# or directly:  ./scripts/smoke-test-local.sh
```

Expected output: a health `ok`, a catalog of 5 products, a cart with the added
item, an order response containing an `order` (status `PENDING`) and a
`payment` (status `SUCCESS`), and a `payments_total{status="succeeded"}` metric.

**Prefer a browser?** Start the services in the background and open the
storefront:

```bash
PORT=8081 node services/catalog/src/index.js &
PORT=8082 node services/cart/src/index.js &
PORT=8083 node services/order/src/index.js &
PORT=8084 node services/payment/src/index.js &
PORT=8080 CATALOG_URL=http://localhost:8081 CART_URL=http://localhost:8082 \
  ORDER_URL=http://localhost:8083 PAYMENT_URL=http://localhost:8084 \
  node services/frontend/src/index.js &

open http://localhost:8080/          # then, when done:
pkill -f "src/index.js"
```

> **Note (zsh/macOS):** don't paste comment lines that contain `(` or `)` —
> zsh tries to parse the parentheses. The `make smoke-test` command above
> avoids this entirely.

---

### Level 2 — Containers on local Kubernetes (kind)

Builds the Docker images and deploys the Helm chart to a throwaway
single-node [kind](https://kind.sigs.k8s.io/) cluster. **No VMs, no Terraform.**

**Requires:** Docker running, `kind`, `helm`, `kubectl`.

```bash
# one command: create cluster, build images, load them, helm install
./scripts/local-up.sh
```

Then check it:

```bash
kubectl get pods -n ecommerce          # all 5 services Running
kubectl get svc  -n ecommerce
kubectl -n ecommerce rollout status deployment/frontend

# port-forward the storefront and hit it
kubectl -n ecommerce port-forward svc/frontend 8080:8080 &
curl -s http://localhost:8080/api/products
```

Tear it down:

```bash
./scripts/local-down.sh     # deletes the kind cluster
```

#### Automatic scaling on load (Horizontal Pod Autoscaler)

There are **two independent kinds of scaling** in this project:

| Layer | What scales | How | Reacts in |
| ----- | ----------- | --- | --------- |
| **Pods (app)** | replicas of a service | **automatic** — Kubernetes HPA on CPU | seconds |
| **Nodes (infra)** | machines/VMs | **manual** — Terraform (Level 3) | minutes (deliberate) |

Pod scaling is automatic. The `frontend` and `catalog` services have a
`HorizontalPodAutoscaler` (see `autoscaling.*` in
[`helm/ecommerce/values.yaml`](helm/ecommerce/values.yaml)) that watches CPU and
adds/removes replicas between `minReplicas` and `maxReplicas` on its own. This
needs `metrics-server` in the cluster — the `fresh-start.sh` bring-up installs it
automatically (patched with `--kubelet-insecure-tls` for kind).

See it in action — one command drives traffic and you watch pods scale up, then
back down:

```bash
./scripts/autoscale-demo.sh              # ~2 min of load, then cool down
# watch it live in another terminal:
watch -n 2 kubectl get hpa,pods -n ecommerce
```

Under load the HPA scales `frontend` from 2 up toward 10 pods; when traffic
stops it shrinks back to 2 after the scale-down stabilization window (~5 min).
Node-level auto-scaling in a real cloud is the **Cluster Autoscaler**; the
Terraform node demo in Level 3 is the by-hand version of that layer.

---

### Level 3 — Full IaC pipeline (Terraform + Ansible + k3s)

The real deal: Terraform creates VMs, Ansible installs k3s and deploys, and
upgrades/rollbacks are Ansible-driven. **This is the intended production-like
path.**

**Requires:** Multipass, Terraform, Ansible, Helm, Docker, and a container
registry the VMs can reach (a local one works for a demo):

```bash
docker run -d -p 5000:5000 --name registry registry:2
```

**1. Provision the VMs (Terraform creates the instances + Ansible inventory):**

```bash
make infra-up
# equivalent to:
#   terraform -chdir=terraform/environments/local-k8s init
#   terraform -chdir=terraform/environments/local-k8s apply -var-file=local-k8s.tfvars
```

**2. Install k3s and bootstrap the cluster (Ansible):**

```bash
make cluster
# runs ansible/playbooks/site.yml against the generated inventory
```

**3. Build & push the service images:**

```bash
make build-images IMAGE_TAG=v1 REGISTRY=localhost:5000
```

**4. Deploy the app (Ansible → Helm):**

```bash
make deploy IMAGE_TAG=v1
```

**5. Test upgrades and rollback (requirement: done by Ansible):**

```bash
make rollout  IMAGE_TAG=v2     # rolling upgrade, verifies every Deployment
make rollback                  # revert to the previous release
```

**6. Tear everything down (Terraform deletes the VMs):**

```bash
make infra-down
```

Adjust cluster size in
[`terraform/environments/local-k8s/local-k8s.tfvars`](terraform/environments/local-k8s/local-k8s.tfvars)
(`agent_count`, CPU/memory).

---

## CI/CD with Jenkins

There are **two** pipelines, pick the one that matches how you run the app:

### `Jenkinsfile.kind` — kind + Helm (matches the quick-start / local flow)

Self-contained; **no external registry needed**. Point a Jenkins Pipeline job at
this repo with **Script Path = `Jenkinsfile.kind`**. Stages:

1. **Unit test** every service (`node --check` + `npm test`).
2. **Build** the five images and **Trivy-scan** them (non-blocking).
3. **Ensure cluster** — create the kind cluster if missing, install
   ingress-nginx and **metrics-server** (so the HPA works).
4. **Load images** into kind and **deploy the Helm chart** (`--wait`).
5. **Verify checkout flow** end-to-end (health → products → place an order,
   asserts payment `SUCCESS`).
6. **Autoscaling check** — confirms the HPA is live and reading CPU metrics.

On any post-deploy failure it runs `helm rollback` to the previous revision.
The agent needs `docker`, `kind`, `kubectl`, `helm` on PATH (Trivy optional).
Parameters let you skip deploy, keep/delete the cluster, or rename it.

### `Jenkinsfile` — Ansible + k3s + registry (Level 3, production-like)

1. **Unit test** every service.
2. **Build** and **Trivy-scan** the images.
3. **Push** them to the registry (tagged with the build number).
4. **Deploy** by invoking `ansible-playbook playbooks/rollout.yml` — and on
   failure it automatically runs `rollback.yml`.

To try it: run Jenkins (e.g. `docker run -p 8080:8080 jenkins/jenkins:lts`),
create a **Pipeline** job, point it at this repo, and set the `REGISTRY`
environment variable on the agent. The agent needs `docker`, `ansible`, and
`helm` available, plus the kubeconfig at `ansible/.kube/config` (produced by
`make cluster`).

---

## Repository layout

```
.
├── services/           # 5 microservices (frontend, catalog, cart, order, payment)
├── terraform/          # Multipass VM provisioning (module + local-k8s env)
├── ansible/            # k3s install + deploy/rollout/rollback playbooks
├── helm/ecommerce/     # Application Helm chart (+ values-k3s.yaml, values-local.yaml)
├── monitoring/         # Prometheus, Grafana, Loki, Alertmanager configs
├── loadtest/           # k6 load-test scripts
├── scripts/            # local-up.sh / local-down.sh (kind helpers)
├── Jenkinsfile         # CI/CD pipeline
├── Makefile            # Entry points for every task (run `make help`)
├── docs/               # architecture.md, deployment.md, runbook.md
└── archive/            # Original AWS implementation (reference only)
```

Run `make help` to see every available target.

---

## Troubleshooting

| Symptom | Fix |
| ------- | --- |
| `Cannot connect to the Docker daemon` | Start Docker Desktop, or `colima start`. |
| `terraform: command not found` | Only needed for Level 3. `brew install terraform`. |
| `multipass: command not found` | Level 3 only. `brew install --cask multipass`. |
| Port 8080 already in use (Level 1) | Stop the old process: `pkill -f "src/index.js"`. |
| `npm test` shows `tests 0` for a service | Only `catalog` ships tests today; the others are stubs. |
| Payment sometimes returns `402` | Expected — `payment` has a 2% mock failure rate (`PAYMENT_FAILURE_RATE`). |
| kind pods stuck `ImagePullBackOff` | Re-run `./scripts/local-up.sh`; it loads images into kind with `kind load`. |
| k3s agents won't join (Level 3) | Ensure the VMs can reach the server on port 6443; re-run `make cluster`. |

---

## License

MIT — see [LICENSE](LICENSE).
