# E-Commerce Platform — End-to-End AWS Deployment

Reference scaffold for deploying a containerized e-commerce application on AWS
using **Terraform**, **Ansible**, **Amazon EKS**, **Helm**, and an open-source
**Prometheus / Grafana / Loki** observability stack.

This repository is the implementation companion to the MajorProject Progress
Report — I (May 2026).

## Repository Layout

```
.
├── terraform/          # Infrastructure as code (modules + environments)
│   ├── modules/        # Reusable building blocks: network, eks, rds, ecr, ...
│   └── environments/   # Per-environment root modules: dev, staging, prod
├── ansible/            # Configuration management (roles + inventories)
├── services/           # Microservices source: frontend, catalog, cart, order, payment
├── helm/               # Helm charts for the application and umbrella deployment
├── monitoring/         # Prometheus, Grafana dashboards, Loki, Alertmanager configs
├── loadtest/           # k6 load-test scripts and traffic CSVs
├── local/              # kind cluster configuration for local development
├── .github/workflows/  # CI/CD pipelines
├── scripts/            # Helper scripts (bootstrap, deploy, teardown)
└── docs/               # Architecture diagrams and runbooks
```

## Quick Start (local)

```bash
# 1. Bring up a local Kubernetes cluster
make kind-up

# 2. Build and load the service images into the cluster
make build-images

# 3. Deploy the application via Helm
make deploy-local

# 4. Open the storefront
open http://localhost:8080
```

## Quick Start (AWS)

> AWS deployment requires AWS credentials, a registered domain, and will
> incur cost. Read [docs/aws-deployment.md](docs/aws-deployment.md) before
> running.

```bash
cd terraform/environments/dev
terraform init
terraform plan -var-file=dev.tfvars
terraform apply -var-file=dev.tfvars

ansible-playbook -i ../../../ansible/inventories/dev playbooks/site.yml

helm upgrade --install ecommerce ../../../helm/ecommerce \
  --namespace ecommerce --create-namespace \
  --values ../../../helm/ecommerce/values-dev.yaml
```

## Tooling

See [.tool-versions](.tool-versions). This project pins:

- Terraform 1.7.x
- Ansible 9.x
- kubectl 1.29.x
- helm 3.14.x
- AWS CLI v2

## License

MIT
