#!/usr/bin/env bash
# One-shot macOS setup: install every prerequisite (via Homebrew), start the
# Docker backend (Colima), then build and run the whole application on a local
# Kubernetes (kind) cluster and verify it end-to-end.
#
#   ./scripts/setup-mac.sh              # install prereqs + run everything
#   ./scripts/setup-mac.sh --no-install # skip installs, just run (tools must exist)
#   ./scripts/setup-mac.sh --no-open    # don't open the browser at the end
#   ./scripts/setup-mac.sh --clean      # tear everything down (no rebuild)
#
# Safe to re-run: Homebrew skips already-installed tools and the run step wipes
# and rebuilds from scratch.
set -euo pipefail

DO_INSTALL=1
RUN_ARGS=()   # forwarded to fresh-start.sh (e.g. --no-open)
for arg in "$@"; do
  case "$arg" in
    --no-install)       DO_INSTALL=0 ;;
    --no-open|--clean)  RUN_ARGS+=("$arg") ;;
    *) echo "unknown option: $arg" >&2; exit 2 ;;
  esac
done

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

say() { printf '\n\033[1;36m==> %s\033[0m\n' "$1"; }

# --- Homebrew --------------------------------------------------------------
if [[ $DO_INSTALL -eq 1 ]]; then
  if ! command -v brew >/dev/null 2>&1; then
    cat >&2 <<'EOF'
Homebrew is required to auto-install the tools. Install it from https://brew.sh
then re-run this script, or install the tools yourself and pass --no-install:
  node, kind, kubectl, helm, colima, docker
EOF
    exit 1
  fi

  say "Installing prerequisites with Homebrew"
  # CLI tools (formulae). 'docker' here is just the client; Colima is the daemon.
  # kubectl is shipped by the 'kubernetes-cli' formula, so check by command
  # rather than formula name to avoid needless reinstalls.
  install_tool() {
    local cmd="$1" formula="$2"
    if command -v "$cmd" >/dev/null 2>&1; then
      echo "  $cmd already installed"
    else
      echo "  installing $formula"
      brew install "$formula"
    fi
  }
  install_tool node   node
  install_tool kind   kind
  install_tool kubectl kubernetes-cli
  install_tool helm   helm
  install_tool colima colima
  install_tool docker docker
  hash -r
fi

# --- Docker daemon (Colima) ------------------------------------------------
say "Starting the Docker backend (Colima)"
if ! command -v colima >/dev/null 2>&1; then
  echo "ERROR: colima not found. Install it or start Docker Desktop, then re-run." >&2
  exit 1
fi
if ! colima status >/dev/null 2>&1; then
  colima start --cpu 4 --memory 6
else
  echo "  Colima already running"
fi

if [[ -z "${DOCKER_HOST:-}" && -S "$HOME/.colima/default/docker.sock" ]]; then
  export DOCKER_HOST="unix://$HOME/.colima/default/docker.sock"
fi

if ! docker info >/dev/null 2>&1; then
  echo "ERROR: Docker daemon not reachable even after starting Colima." >&2
  echo "Try: colima delete && colima start --cpu 4 --memory 6" >&2
  exit 1
fi
echo "  Docker daemon is up"

# --- Build + run everything ------------------------------------------------
say "Building and running the application"
exec ./scripts/fresh-start.sh ${RUN_ARGS[@]+"${RUN_ARGS[@]}"}
