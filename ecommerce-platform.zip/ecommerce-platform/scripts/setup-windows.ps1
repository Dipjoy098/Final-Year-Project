<#
.SYNOPSIS
  One-shot Windows setup: install prerequisites (via winget), ensure Docker
  Desktop is running, then build and run the whole application on a local
  Kubernetes (kind) cluster and verify it end-to-end.

.DESCRIPTION
  Run from PowerShell in the repository root:

      powershell -ExecutionPolicy Bypass -File .\scripts\setup-windows.ps1

  Options:
      -NoInstall    Skip winget installs; tools must already be present.
      -NoOpen       Don't open the storefront in a browser at the end.

  Safe to re-run: winget skips already-installed tools and the run step wipes
  and rebuilds the cluster from scratch. Requires Docker Desktop (Windows
  containers OFF / Linux containers mode).
#>
[CmdletBinding()]
param(
  [switch]$NoInstall,
  [switch]$NoOpen
)

$ErrorActionPreference = "Stop"
$Cluster  = if ($env:KIND_CLUSTER) { $env:KIND_CLUSTER } else { "ecommerce" }
$Services = @("frontend","catalog","cart","order","payment")

# Move to the repo root (this script lives in <root>\scripts).
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

function Say([string]$msg) { Write-Host "`n==> $msg" -ForegroundColor Cyan }
function Have([string]$cmd) { [bool](Get-Command $cmd -ErrorAction SilentlyContinue) }

# --- prerequisites ---------------------------------------------------------
if (-not $NoInstall) {
  if (-not (Have "winget")) {
    Write-Error "winget not found. Install 'App Installer' from the Microsoft Store, or pass -NoInstall and install node/kind/kubectl/helm + Docker Desktop yourself."
    exit 1
  }

  Say "Installing prerequisites with winget"
  # id = winget package id ; cmd = the executable it provides
  $pkgs = @(
    @{ id = "OpenJS.NodeJS.LTS";      cmd = "node" },
    @{ id = "Kubernetes.kubectl";     cmd = "kubectl" },
    @{ id = "Kubernetes.kind";        cmd = "kind" },
    @{ id = "Helm.Helm";              cmd = "helm" },
    @{ id = "Docker.DockerDesktop";   cmd = "docker" }
  )
  foreach ($p in $pkgs) {
    if (Have $p.cmd) {
      Write-Host "  $($p.cmd) already installed"
    } else {
      Write-Host "  installing $($p.id)"
      winget install --id $p.id -e --accept-source-agreements --accept-package-agreements
    }
  }
  # winget updates PATH for new shells; refresh it for this session.
  $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" +
              [System.Environment]::GetEnvironmentVariable("Path","User")
}

foreach ($t in @("node","kubectl","kind","helm","docker")) {
  if (-not (Have $t)) {
    Write-Error "Required tool '$t' is not on PATH. Open a NEW PowerShell window (so PATH refreshes) and re-run, or install it manually."
    exit 1
  }
}

# --- Docker daemon (Docker Desktop) ---------------------------------------
Say "Ensuring Docker Desktop is running"
if (-not (docker info 2>$null)) {
  $dd = "$env:ProgramFiles\Docker\Docker\Docker Desktop.exe"
  if (Test-Path $dd) {
    Write-Host "  launching Docker Desktop..."
    Start-Process $dd | Out-Null
  }
  Write-Host "  waiting for the Docker daemon (up to 3 min)..."
  $ok = $false
  foreach ($i in 1..90) {
    Start-Sleep -Seconds 2
    docker info *> $null
    if ($LASTEXITCODE -eq 0) { $ok = $true; break }
  }
  if (-not $ok) {
    Write-Error "Docker daemon did not become ready. Start Docker Desktop manually (Linux containers mode) and re-run."
    exit 1
  }
}
Write-Host "  Docker daemon is up"

# --- teardown --------------------------------------------------------------
Say "Cleaning any previous run"
helm uninstall ecommerce -n ecommerce 2>$null | Out-Null
kind delete cluster --name $Cluster 2>$null | Out-Null

# --- syntax check ----------------------------------------------------------
Say "Syntax-checking service source"
foreach ($svc in $Services) {
  node --check "services/$svc/src/index.js"
  if ($LASTEXITCODE -ne 0) { Write-Error "syntax error in $svc"; exit 1 }
}
Write-Host "  all services parse OK"

# --- cluster ---------------------------------------------------------------
Say "Creating a fresh kind cluster '$Cluster'"
kind create cluster --name $Cluster --config local/kind/cluster.yaml
kubectl config use-context "kind-$Cluster"

Say "Installing ingress-nginx"
kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/main/deploy/static/provider/kind/deploy.yaml
kubectl wait --namespace ingress-nginx `
  --for=condition=ready pod `
  --selector=app.kubernetes.io/component=controller `
  --timeout=180s

# --- images ----------------------------------------------------------------
Say "Building and loading images"
foreach ($svc in $Services) {
  Write-Host "  - $svc"
  docker build -q -t "ecommerce/${svc}:local" "services/$svc" | Out-Null
  kind load docker-image "ecommerce/${svc}:local" --name $Cluster | Out-Null
}

# --- deploy ----------------------------------------------------------------
Say "Deploying the Helm chart"
helm upgrade --install ecommerce helm/ecommerce `
  --namespace ecommerce --create-namespace `
  -f helm/ecommerce/values-local.yaml

Say "Waiting for all deployments to become available"
kubectl -n ecommerce wait --for=condition=available deployment --all --timeout=180s

# --- verify ----------------------------------------------------------------
Say "Pods"
kubectl get pods -n ecommerce

Say "Smoke-testing the checkout flow"
$pf = Start-Process kubectl -PassThru -WindowStyle Hidden `
  -ArgumentList "-n","ecommerce","port-forward","svc/frontend","8080:8080"
try {
  $ready = $false
  foreach ($i in 1..20) {
    Start-Sleep -Milliseconds 500
    try { Invoke-RestMethod "http://localhost:8080/healthz" -TimeoutSec 2 | Out-Null; $ready = $true; break } catch {}
  }
  if ($ready) {
    $health   = Invoke-RestMethod "http://localhost:8080/healthz"
    $products = Invoke-RestMethod "http://localhost:8080/api/products"
    $order    = Invoke-RestMethod "http://localhost:8080/api/orders" -Method Post `
      -ContentType "application/json" `
      -Body '{"userId":"smoke","items":[{"productId":"p-001","quantity":1}],"total":19.99}'
    Write-Host "  health:   $($health.status)"
    Write-Host "  products: $($products.products.Count) found"
    Write-Host "  checkout: order $($order.order.status) / payment $($order.payment.status)"
  } else {
    Write-Host "  (could not reach the frontend to smoke-test; pods are up though)" -ForegroundColor Yellow
  }
} finally {
  if ($pf) { Stop-Process -Id $pf.Id -ErrorAction SilentlyContinue }
}

# --- done ------------------------------------------------------------------
Write-Host "`n[OK] Fresh stack is up." -ForegroundColor Green
Write-Host @"

  Open the storefront by starting a port-forward and browsing to it:
    kubectl -n ecommerce port-forward svc/frontend 8080:8080
    # then open http://localhost:8080/

  Pods:        kubectl get pods -n ecommerce
  Tear down:   helm uninstall ecommerce -n ecommerce; kind delete cluster --name $Cluster
"@

if (-not $NoOpen) {
  # Leave a port-forward running in a separate window so the browser works.
  Start-Process kubectl -ArgumentList "-n","ecommerce","port-forward","svc/frontend","8080:8080"
  Start-Sleep -Seconds 3
  Start-Process "http://localhost:8080/"
}
