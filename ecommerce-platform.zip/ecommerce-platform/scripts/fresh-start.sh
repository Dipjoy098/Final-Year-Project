#!/usr/bin/env bash
# Fresh start: wipe every local artifact this project creates, then rebuild the
# whole Level 2 stack from zero and verify it end-to-end.
#
#   ./scripts/fresh-start.sh            # clean + rebuild + verify
#   ./scripts/fresh-start.sh --clean    # only tear everything down
#   ./scripts/fresh-start.sh --no-open  # rebuild but don't open the browser
#
# Requires: docker (running), kind, kubectl, helm. Node is optional (used only
# for a pre-build syntax check).
set -euo pipefail

CLUSTER="${KIND_CLUSTER:-ecommerce}"
TF_DEMO_DIR="terraform/environments/local-docker"
SERVICES=(frontend catalog cart order payment)
CLEAN_ONLY=0
OPEN_BROWSER=1

for arg in "$@"; do
  case "$arg" in
    --clean)   CLEAN_ONLY=1 ;;
    --no-open) OPEN_BROWSER=0 ;;
    *) echo "unknown option: $arg" >&2; exit 2 ;;
  esac
done

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

# Point Docker/Terraform at Colima's socket if it exists and DOCKER_HOST is unset.
if [[ -z "${DOCKER_HOST:-}" && -S "$HOME/.colima/default/docker.sock" ]]; then
  export DOCKER_HOST="unix://$HOME/.colima/default/docker.sock"
fi

say() { printf '\n\033[1;36m==> %s\033[0m\n' "$1"; }

# --- preflight -------------------------------------------------------------
missing=0
for tool in docker kind kubectl helm; do
  command -v "$tool" >/dev/null 2>&1 || { echo "MISSING: $tool" >&2; missing=1; }
done
if [[ $missing -eq 1 ]]; then
  cat >&2 <<'EOF'

Install the missing tools first:
  brew install kind kubectl helm
  # Docker: start Docker Desktop, or `brew install colima docker && colima start`
EOF
  exit 1
fi
if ! docker info >/dev/null 2>&1; then
  echo "ERROR: the Docker daemon is not running. Start Docker Desktop or run 'colima start'." >&2
  exit 1
fi

# --- teardown --------------------------------------------------------------
say "Stopping any leftover port-forwards"
pkill -f "port-forward svc/frontend" 2>/dev/null || true

say "Destroying the Terraform scaling demo (if any)"
if [[ -d "$TF_DEMO_DIR/.terraform" ]]; then
  terraform -chdir="$TF_DEMO_DIR" destroy -auto-approve >/dev/null 2>&1 || true
fi
# Belt and braces: remove any stray demo containers Terraform didn't track.
docker ps -aq --filter "label=cluster=ecommerce-demo" | xargs -r docker rm -f >/dev/null 2>&1 || true

say "Deleting the kind cluster '$CLUSTER'"
helm uninstall ecommerce -n ecommerce >/dev/null 2>&1 || true
kind delete cluster --name "$CLUSTER" >/dev/null 2>&1 || true

if [[ $CLEAN_ONLY -eq 1 ]]; then
  say "Clean complete. Nothing is running."
  exit 0
fi

# --- optional syntax check -------------------------------------------------
if command -v node >/dev/null 2>&1; then
  say "Syntax-checking service source"
  for svc in "${SERVICES[@]}"; do
    node --check "services/$svc/src/index.js"
  done
  echo "all services parse OK"
fi

# --- cluster ---------------------------------------------------------------
say "Creating a fresh kind cluster '$CLUSTER'"
kind create cluster --name "$CLUSTER" --config local/kind/cluster.yaml
kubectl config use-context "kind-$CLUSTER"

say "Installing ingress-nginx"
kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/main/deploy/static/provider/kind/deploy.yaml
kubectl wait --namespace ingress-nginx \
  --for=condition=ready pod \
  --selector=app.kubernetes.io/component=controller \
  --timeout=180s

# --- images ----------------------------------------------------------------
say "Building and loading images"
for svc in "${SERVICES[@]}"; do
  echo "  - $svc"
  docker build -q -t "ecommerce/$svc:local" "services/$svc" >/dev/null
  kind load docker-image "ecommerce/$svc:local" --name "$CLUSTER" >/dev/null
done

# --- deploy ----------------------------------------------------------------
say "Deploying the Helm chart"
helm upgrade --install ecommerce helm/ecommerce \
  --namespace ecommerce --create-namespace \
  -f helm/ecommerce/values-local.yaml

say "Waiting for all deployments to become available"
kubectl -n ecommerce wait --for=condition=available deployment --all --timeout=180s

# --- verify ----------------------------------------------------------------
say "Pods"
kubectl get pods -n ecommerce

say "Smoke-testing the checkout flow"
kubectl -n ecommerce port-forward svc/frontend 8080:8080 >/tmp/frontend-pf.log 2>&1 &
PF=$!
trap 'kill "$PF" 2>/dev/null || true' EXIT
for _ in $(seq 1 20); do
  curl -sf http://localhost:8080/healthz >/dev/null 2>&1 && break
  sleep 0.5
done
echo "  health:   $(curl -s http://localhost:8080/healthz)"
echo "  products: $(curl -s http://localhost:8080/api/products | grep -o '"name"' | wc -l | tr -d ' ') found"
ORDER=$(curl -s -X POST http://localhost:8080/api/orders \
  -H 'content-type: application/json' \
  -d '{"userId":"smoke","items":[{"productId":"p-001","quantity":1}],"total":19.99}')
echo "  checkout: $ORDER"

# --- done ------------------------------------------------------------------
trap - EXIT   # keep the port-forward alive for the user
cat <<EOF

$(printf '\033[1;32m✔ Fresh stack is up.\033[0m')

  Storefront:  http://localhost:8080/   (port-forward PID $PF is still running)
  Pods:        kubectl get pods -n ecommerce

  Terraform scaling demo:
    cd $TF_DEMO_DIR && terraform init && terraform apply

  Tear it all down again:
    ./scripts/fresh-start.sh --clean
EOF

if [[ $OPEN_BROWSER -eq 1 ]] && command -v open >/dev/null 2>&1; then
  open http://localhost:8080/ || true
fi
