#!/usr/bin/env bash
# Tear down the local kind cluster.
set -euo pipefail
CLUSTER="${KIND_CLUSTER:-ecommerce}"
helm uninstall ecommerce -n ecommerce || true
kind delete cluster --name "$CLUSTER"
