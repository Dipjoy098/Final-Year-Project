#!/usr/bin/env bash
# ============================================================================
# Portable CI pipeline stages for the ecommerce-platform.
#
# Each stage of the pipeline is a function here, dispatched by name. This keeps
# ALL the shell logic in one bash file (works in Git Bash on Windows and in a
# normal shell on macOS/Linux) so the Jenkinsfile stays a thin wrapper that just
# calls:  bash scripts/ci-pipeline.sh <stage>
#
# Stages:
#   test      unit-test + syntax-check every service
#   build     docker build the five images (tag :local)
#   scan      Trivy scan (non-blocking; skipped if trivy is absent)
#   cluster   ensure kind cluster + ingress-nginx + metrics-server
#   load      kind load the images
#   deploy    helm upgrade --install + rollout restart
#   verify    smoke-test the checkout flow end-to-end
#   hpa       confirm the HorizontalPodAutoscaler is reading CPU metrics
#   rollback  helm rollback to the previous revision (used on failure)
#   all       run test build scan cluster load deploy verify hpa in order
#
# Env overrides: CLUSTER (default ecommerce-ci), NAMESPACE (default ecommerce),
#                PF_PORT (default 18080).
# ============================================================================
set -euo pipefail

CLUSTER="${CLUSTER:-ecommerce-ci}"
NAMESPACE="${NAMESPACE:-ecommerce}"
PF_PORT="${PF_PORT:-18080}"
SERVICES=(frontend catalog cart order payment)

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

# On macOS with Colima, point at its socket if nothing else is set. On Windows
# (Docker Desktop) DOCKER_HOST stays unset and docker works directly.
if [[ -z "${DOCKER_HOST:-}" && -S "$HOME/.colima/default/docker.sock" ]]; then
  export DOCKER_HOST="unix://$HOME/.colima/default/docker.sock"
fi

say() { printf '\n\033[1;36m==> %s\033[0m\n' "$1"; }
die() { printf '\033[1;31mERROR: %s\033[0m\n' "$1" >&2; exit 1; }

stage_test() {
  say "Unit test + syntax check"
  for svc in "${SERVICES[@]}"; do
    echo "--- $svc ---"
    node --check "services/$svc/src/index.js"
    ( cd "services/$svc" && npm install --no-audit --no-fund && npm test --if-present )
  done
  echo "all services pass"
}

stage_build() {
  say "Build images"
  for svc in "${SERVICES[@]}"; do
    echo "--- building $svc ---"
    docker build -t "ecommerce/$svc:local" "services/$svc"
  done
}

stage_scan() {
  say "Scan images (Trivy, non-blocking)"
  if ! command -v trivy >/dev/null 2>&1; then
    echo "trivy not installed — skipping"
    return 0
  fi
  for svc in "${SERVICES[@]}"; do
    trivy image --exit-code 0 --ignore-unfixed --severity HIGH,CRITICAL \
      "ecommerce/$svc:local" || true
  done
}

stage_cluster() {
  say "Ensure kind cluster '$CLUSTER'"
  if ! kind get clusters 2>/dev/null | grep -qx "$CLUSTER"; then
    kind create cluster --name "$CLUSTER" --config local/kind/cluster.yaml
  else
    echo "reusing existing cluster"
  fi
  kubectl config use-context "kind-$CLUSTER"

  say "ingress-nginx"
  kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/main/deploy/static/provider/kind/deploy.yaml
  kubectl wait --namespace ingress-nginx --for=condition=ready pod \
    --selector=app.kubernetes.io/component=controller --timeout=180s

  say "metrics-server (powers the HPA)"
  kubectl apply -f https://github.com/kubernetes-sigs/metrics-server/releases/latest/download/components.yaml
  kubectl -n kube-system patch deployment metrics-server --type=json \
    -p '[{"op":"add","path":"/spec/template/spec/containers/0/args/-","value":"--kubelet-insecure-tls"}]' || true
  kubectl -n kube-system rollout status deployment/metrics-server --timeout=120s
}

stage_load() {
  say "Load images into kind"
  for svc in "${SERVICES[@]}"; do
    kind load docker-image "ecommerce/$svc:local" --name "$CLUSTER"
  done
}

stage_deploy() {
  say "Deploy (Helm)"
  helm upgrade --install ecommerce helm/ecommerce \
    --namespace "$NAMESPACE" --create-namespace \
    -f helm/ecommerce/values-local.yaml --wait --timeout 5m
  kubectl -n "$NAMESPACE" rollout restart deployment --all
  kubectl -n "$NAMESPACE" rollout status deployment --all --timeout=180s
}

stage_verify() {
  say "Verify checkout flow"
  kubectl -n "$NAMESPACE" port-forward "svc/frontend" "${PF_PORT}:8080" >/tmp/ci-pf.log 2>&1 &
  local pf=$!
  trap 'kill "$pf" 2>/dev/null || true' RETURN
  local base="http://localhost:${PF_PORT}"
  local i
  for i in $(seq 1 30); do
    curl -sf "$base/healthz" >/dev/null 2>&1 && break
    sleep 1
  done
  echo "  health:   $(curl -s "$base/healthz")"
  local products
  products=$(curl -s "$base/api/products" | grep -o '"name"' | wc -l | tr -d ' ')
  echo "  products: $products on the menu"
  [[ "$products" -gt 0 ]] || die "no products returned"
  local order
  order=$(curl -s -X POST "$base/api/orders" -H 'content-type: application/json' \
    -d '{"userId":"ci","items":[{"productId":"p-001","quantity":1}],"total":228}')
  echo "  checkout: $order"
  echo "$order" | grep -q '"status":"SUCCESS"' || die "payment did not succeed"
  echo "  checkout flow verified"
}

stage_hpa() {
  say "Autoscaling check (HPA)"
  kubectl get hpa -n "$NAMESPACE"
  if kubectl get hpa -n "$NAMESPACE" -o wide | grep -q '<unknown>'; then
    die "HPA has no CPU metrics — metrics-server is not working"
  fi
  echo "  HPA is live and reading CPU metrics"
}

stage_rollback() {
  say "Rolling back the Helm release"
  if helm history ecommerce -n "$NAMESPACE" >/dev/null 2>&1; then
    helm rollback ecommerce -n "$NAMESPACE" --wait --timeout 3m || true
  fi
}

stage_all() {
  stage_test; stage_build; stage_scan; stage_cluster; stage_load
  stage_deploy; stage_verify; stage_hpa
  say "Pipeline passed ✔"
}

STAGE="${1:-all}"
case "$STAGE" in
  test)     stage_test ;;
  build)    stage_build ;;
  scan)     stage_scan ;;
  cluster)  stage_cluster ;;
  load)     stage_load ;;
  deploy)   stage_deploy ;;
  verify)   stage_verify ;;
  hpa)      stage_hpa ;;
  rollback) stage_rollback ;;
  all)      stage_all ;;
  *) die "unknown stage: $STAGE (use: test build scan cluster load deploy verify hpa rollback all)" ;;
esac
