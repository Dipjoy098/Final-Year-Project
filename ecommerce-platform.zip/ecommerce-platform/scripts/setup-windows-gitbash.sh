#!/usr/bin/env bash
# ============================================================================
# Bare-PC Windows setup, driven entirely from Git Bash.
#
# Assumes a brand-new Windows machine with ONLY Git for Windows installed
# (which is what gives you Git Bash, curl and cygpath). No winget, choco or
# scoop required. This script downloads Node, kubectl, kind and helm directly
# into a user-local folder (NO admin needed), then makes sure Docker Desktop is
# present and running, then builds and runs the whole application on a local
# Kubernetes (kind) cluster and verifies it end-to-end.
#
# Run it from the repo root, inside Git Bash:
#
#     ./scripts/setup-windows-gitbash.sh
#
# Options:
#     --no-open      don't open the storefront in a browser at the end
#     --tools-only   install the tools + check Docker, but don't build/run
#
# Safe to re-run: already-installed tools are skipped and the run step wipes
# and rebuilds from scratch.
# ============================================================================
set -euo pipefail

# ---- pinned versions (edit here to upgrade) --------------------------------
NODE_VER="20.14.0"
KUBECTL_VER="1.29.6"
KIND_VER="0.23.0"
HELM_VER="3.14.4"

# ---- options ---------------------------------------------------------------
OPEN_BROWSER=1
TOOLS_ONLY=0
for arg in "$@"; do
  case "$arg" in
    --no-open)    OPEN_BROWSER=0 ;;
    --tools-only) TOOLS_ONLY=1 ;;
    *) echo "unknown option: $arg" >&2; exit 2 ;;
  esac
done

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

TOOLS="$HOME/.ecommerce-tools"
BIN="$TOOLS/bin"
NODE_DIR="$TOOLS/node-v${NODE_VER}-win-x64"
mkdir -p "$BIN"

say()  { printf '\n\033[1;36m==> %s\033[0m\n' "$1"; }
info() { printf '    %s\n' "$1"; }
warn() { printf '\033[1;33m    %s\033[0m\n' "$1"; }
die()  { printf '\033[1;31mERROR: %s\033[0m\n' "$1" >&2; exit 1; }

command -v curl >/dev/null 2>&1 || die "curl not found. Reinstall Git for Windows (it bundles curl)."

# Expand a .zip using the Windows-native tools (PowerShell), since Git Bash has
# no 'unzip'. Args: <zip-path> <dest-dir> (both POSIX paths).
unzip_win() {
  local zip="$1" dest="$2"
  local wzip wdest
  wzip="$(cygpath -w "$zip")"
  wdest="$(cygpath -w "$dest")"
  powershell -NoProfile -Command \
    "Expand-Archive -LiteralPath '$wzip' -DestinationPath '$wdest' -Force" \
    || die "failed to unzip $zip"
}

dl() { # dl <url> <output-path>
  info "downloading $(basename "$2")"
  curl -fL --retry 3 -o "$2" "$1" || die "download failed: $1"
}

# ---- Node.js (portable zip, no admin) --------------------------------------
say "Node.js ${NODE_VER}"
if command -v node >/dev/null 2>&1; then
  info "node already on PATH ($(node --version)) — skipping"
elif [[ -x "$NODE_DIR/node.exe" ]]; then
  info "already downloaded to $NODE_DIR"
else
  tmp="$TOOLS/node.zip"
  dl "https://nodejs.org/dist/v${NODE_VER}/node-v${NODE_VER}-win-x64.zip" "$tmp"
  unzip_win "$tmp" "$TOOLS"
  rm -f "$tmp"
  info "installed to $NODE_DIR"
fi

# ---- kubectl (single exe) --------------------------------------------------
say "kubectl ${KUBECTL_VER}"
if command -v kubectl >/dev/null 2>&1; then
  info "kubectl already on PATH — skipping"
elif [[ -x "$BIN/kubectl.exe" ]]; then
  info "already present in $BIN"
else
  dl "https://dl.k8s.io/release/v${KUBECTL_VER}/bin/windows/amd64/kubectl.exe" "$BIN/kubectl.exe"
fi

# ---- kind (single exe) -----------------------------------------------------
say "kind ${KIND_VER}"
if command -v kind >/dev/null 2>&1; then
  info "kind already on PATH — skipping"
elif [[ -x "$BIN/kind.exe" ]]; then
  info "already present in $BIN"
else
  dl "https://kind.sigs.k8s.io/dl/v${KIND_VER}/kind-windows-amd64" "$BIN/kind.exe"
fi

# ---- helm (zip) ------------------------------------------------------------
say "helm ${HELM_VER}"
if command -v helm >/dev/null 2>&1; then
  info "helm already on PATH — skipping"
elif [[ -x "$BIN/helm.exe" ]]; then
  info "already present in $BIN"
else
  tmp="$TOOLS/helm.zip"
  dl "https://get.helm.sh/helm-v${HELM_VER}-windows-amd64.zip" "$tmp"
  unzip_win "$tmp" "$TOOLS/helm-tmp"
  cp "$TOOLS/helm-tmp/windows-amd64/helm.exe" "$BIN/helm.exe"
  rm -rf "$tmp" "$TOOLS/helm-tmp"
fi

# ---- wire the tools onto PATH (this session + future Git Bash sessions) ----
export PATH="$BIN:$NODE_DIR:$PATH"

BASHRC="$HOME/.bashrc"
MARKER="# >>> ecommerce-platform tools >>>"
if ! grep -qF "$MARKER" "$BASHRC" 2>/dev/null; then
  {
    echo ""
    echo "$MARKER"
    echo "export PATH=\"$BIN:$NODE_DIR:\$PATH\""
    echo "# <<< ecommerce-platform tools <<<"
  } >> "$BASHRC"
  info "added the tools folder to your PATH in ~/.bashrc"
fi

say "Verifying the CLI tools"
for t in node kubectl kind helm; do
  if command -v "$t" >/dev/null 2>&1; then
    printf '    %-8s %s\n' "$t" "ok"
  else
    die "$t still not found on PATH — open a NEW Git Bash window and re-run."
  fi
done

# ---- Docker Desktop --------------------------------------------------------
# Docker Desktop is the one piece that needs administrator rights + WSL2, so it
# cannot be dropped in as a user-local binary. We install/launch it and wait.
say "Docker"
DOCKER_APP="/c/Program Files/Docker/Docker/Docker Desktop.exe"

if docker info >/dev/null 2>&1; then
  info "Docker daemon is already running"
else
  if [[ ! -e "$DOCKER_APP" ]]; then
    warn "Docker Desktop is not installed."
    tmp="$TOOLS/DockerDesktopInstaller.exe"
    dl "https://desktop.docker.com/win/main/amd64/Docker%20Desktop%20Installer.exe" "$tmp"
    warn "Launching the Docker Desktop installer."
    warn "It needs ADMINISTRATOR rights and will enable WSL2. Follow the wizard,"
    warn "then REBOOT if it asks, start Docker Desktop, and re-run this script."
    # Interactive install (needs the UAC prompt); this blocks until the wizard exits.
    "$tmp" || true
    die "Docker Desktop install started. Finish it, ensure it is running, then re-run: ./scripts/setup-windows-gitbash.sh"
  fi

  warn "Docker Desktop is installed but not running — launching it..."
  "$DOCKER_APP" &
  info "waiting for the Docker daemon (up to 3 minutes)..."
  ok=0
  for _ in $(seq 1 90); do
    if docker info >/dev/null 2>&1; then ok=1; break; fi
    sleep 2
  done
  [[ $ok -eq 1 ]] || die "Docker did not become ready. Open Docker Desktop, wait until it says 'running' (Linux containers mode), then re-run."
fi
info "Docker daemon is up"

if [[ $TOOLS_ONLY -eq 1 ]]; then
  say "Tools installed and Docker is ready. Skipping build (--tools-only)."
  exit 0
fi

# ---- build + run the whole stack ------------------------------------------
say "Building and running the application"
bash ./scripts/fresh-start.sh --no-open

# ---- open the storefront ---------------------------------------------------
say "Opening the storefront"
pkill -f "port-forward svc/frontend" 2>/dev/null || true
kubectl -n ecommerce port-forward svc/frontend 8080:8080 >/tmp/frontend-pf.log 2>&1 &
sleep 3
if [[ $OPEN_BROWSER -eq 1 ]]; then
  # 'start' is a cmd builtin; invoke it through cmd from Git Bash.
  cmd //c start http://localhost:8080/ >/dev/null 2>&1 || true
fi

cat <<'EOF'

  Storefront:  http://localhost:8080/   (a port-forward is running in this shell)
  Pods:        kubectl get pods -n ecommerce

  Tear it all down again:
    ./scripts/fresh-start.sh --clean
EOF
