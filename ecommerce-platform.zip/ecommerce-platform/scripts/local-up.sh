#!/usr/bin/env bash
# Level 2 bring-up: kind cluster + build images + Helm deploy.
# Requires Docker (running), kind, kubectl, and helm.
set -euo pipefail

CLUSTER="${KIND_CLUSTER:-ecommerce}"
SERVICES=(frontend catalog cart order payment)

# --- preflight -------------------------------------------------------------
missing=0
for tool in docker kind kubectl helm; do
  if ! command -v "$tool" >/dev/null 2>&1; then
    echo "MISSING: $tool" >&2
    missing=1
  fi
done
if [[ $missing -eq 1 ]]; then
  cat >&2 <<'EOF'

Install the missing tools first:
  brew install kind kubectl helm
  # Docker: start Docker Desktop, or `brew install colima docker && colima start`

Then re-run: ./scripts/local-up.sh
EOF
  exit 1
fi

if ! docker info >/dev/null 2>&1; then
  echo "ERROR: the Docker daemon is not running." >&2
  echo "Start Docker Desktop (or run 'colima start'), then re-run this script." >&2
  exit 1
fi

# --- cluster ---------------------------------------------------------------
echo "==> Creating kind cluster '$CLUSTER'"
if ! kind get clusters 2>/dev/null | grep -qx "$CLUSTER"; then
  kind create cluster --name "$CLUSTER" --config local/kind/cluster.yaml
fi
kubectl config use-context "kind-$CLUSTER"

echo "==> Installing ingress-nginx"
kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/main/deploy/static/provider/kind/deploy.yaml
kubectl wait --namespace ingress-nginx \
  --for=condition=ready pod \
  --selector=app.kubernetes.io/component=controller \
  --timeout=180s

echo "==> Building and loading images"
for svc in "${SERVICES[@]}"; do
  docker build -t "ecommerce/$svc:local" "services/$svc"
  kind load docker-image "ecommerce/$svc:local" --name "$CLUSTER"
done

echo "==> Helm install"
helm upgrade --install ecommerce helm/ecommerce \
  --namespace ecommerce --create-namespace \
  -f helm/ecommerce/values-local.yaml

echo "==> Waiting for the frontend to become available"
kubectl -n ecommerce rollout status deployment/frontend --timeout=120s

cat <<'EOF'

Done. To reach the storefront:
  kubectl -n ecommerce port-forward svc/frontend 8080:8080
  # then open http://localhost:8080/

Tear down with: ./scripts/local-down.sh
EOF
