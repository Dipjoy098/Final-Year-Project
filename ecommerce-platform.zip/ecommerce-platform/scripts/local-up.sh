#!/usr/bin/env bash
# End-to-end local bring-up: kind cluster, ingress, build images, deploy.
set -euo pipefail

CLUSTER="${KIND_CLUSTER:-ecommerce}"

echo "==> Creating kind cluster '$CLUSTER'"
kind create cluster --name "$CLUSTER" --config local/kind/cluster.yaml || true

echo "==> Installing ingress-nginx"
kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/main/deploy/static/provider/kind/deploy.yaml
kubectl wait --namespace ingress-nginx \
  --for=condition=ready pod \
  --selector=app.kubernetes.io/component=controller \
  --timeout=180s

echo "==> Building images"
for svc in frontend catalog cart order payment; do
  docker build -t "ecommerce/$svc:local" "services/$svc"
  kind load docker-image "ecommerce/$svc:local" --name "$CLUSTER"
done

echo "==> Helm install"
helm upgrade --install ecommerce helm/ecommerce \
  --namespace ecommerce --create-namespace \
  -f helm/ecommerce/values-local.yaml

echo "Done. Storefront: http://localhost:8080/"
