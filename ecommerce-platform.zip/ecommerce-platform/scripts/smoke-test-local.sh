#!/bin/bash
# Level 1 smoke test: start all five services with Node, exercise the full
# browse -> cart -> order -> payment flow, then shut everything down.
# No Docker or Kubernetes required — just Node.js.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

PIDS=()
cleanup() {
  echo ""
  echo "==> Stopping services"
  for pid in "${PIDS[@]:-}"; do kill "$pid" 2>/dev/null || true; done
}
trap cleanup EXIT

echo "==> Installing dependencies (first run only)"
for svc in catalog cart order payment frontend; do
  (cd "services/$svc" && npm install --silent --no-audit --no-fund)
done

echo "==> Starting services"
PORT=8081 node services/catalog/src/index.js >/tmp/catalog.log 2>&1 & PIDS+=($!)
PORT=8082 node services/cart/src/index.js    >/tmp/cart.log    2>&1 & PIDS+=($!)
PORT=8083 node services/order/src/index.js   >/tmp/order.log   2>&1 & PIDS+=($!)
PORT=8084 node services/payment/src/index.js >/tmp/payment.log 2>&1 & PIDS+=($!)
PORT=8080 \
  CATALOG_URL=http://localhost:8081 \
  CART_URL=http://localhost:8082 \
  ORDER_URL=http://localhost:8083 \
  PAYMENT_URL=http://localhost:8084 \
  node services/frontend/src/index.js >/tmp/frontend.log 2>&1 & PIDS+=($!)

echo "==> Waiting for frontend to be ready"
for _ in $(seq 1 20); do
  if curl -sf http://localhost:8080/healthz >/dev/null 2>&1; then break; fi
  sleep 0.5
done

echo ""
echo "==> 1. Health check"
curl -s http://localhost:8080/healthz; echo

echo ""
echo "==> 2. Browse the catalog"
curl -s http://localhost:8080/api/products; echo

echo ""
echo "==> 3. Add an item to the cart"
curl -s -X POST http://localhost:8080/api/cart/user123/items \
  -H 'content-type: application/json' \
  -d '{"productId":"p-001","quantity":2}'; echo

echo ""
echo "==> 4. Place an order (order -> payment -> confirm)"
curl -s -X POST http://localhost:8080/api/orders \
  -H 'content-type: application/json' \
  -d '{"userId":"user123","items":[{"productId":"p-001","quantity":2}],"total":39.98}'; echo

echo ""
echo "==> 5. Prometheus metrics from the payment service"
curl -s http://localhost:8084/metrics | grep payments_total || true

echo ""
echo "==> Smoke test complete."
