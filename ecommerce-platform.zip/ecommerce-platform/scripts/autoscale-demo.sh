#!/usr/bin/env bash
# ============================================================================
# Automatic load-based autoscaling demo (Kubernetes HorizontalPodAutoscaler).
#
# This is the AUTOMATIC counterpart to the manual Terraform scaling demo:
#   - Terraform scales NODES (infrastructure) by hand — a deliberate IaC action.
#   - The HPA scales PODS (the app) automatically, in seconds, based on CPU load.
#
# What it does:
#   1. shows the current pods + HPA state (CPU 0%, replicas at the minimum),
#   2. hammers the storefront with traffic for a while,
#   3. lets you watch the HPA add pods automatically as CPU climbs,
#   4. stops the traffic and lets you watch it scale back down.
#
#   ./scripts/autoscale-demo.sh            # ~2 min of load, then cool down
#   ./scripts/autoscale-demo.sh --load 300 # custom load duration (seconds)
#   ./scripts/autoscale-demo.sh --watch    # just watch the HPA, generate no load
#
# Requires: kubectl (pointed at the running cluster) and either k6 or curl.
# The cluster must already be up (./scripts/fresh-start.sh) WITH metrics-server.
# ============================================================================
set -euo pipefail

NS="ecommerce"
BASE="${BASE_URL:-http://localhost:8080}"
LOAD_SECONDS=120
WATCH_ONLY=0

for ((i=1; i<=$#; i++)); do
  arg="${!i}"
  case "$arg" in
    --load)   j=$((i+1)); LOAD_SECONDS="${!j}"; i=$j ;;
    --watch)  WATCH_ONLY=1 ;;
    *) echo "unknown option: $arg" >&2; exit 2 ;;
  esac
done

say()  { printf '\n\033[1;36m==> %s\033[0m\n' "$1"; }
info() { printf '    %s\n' "$1"; }
die()  { printf '\033[1;31mERROR: %s\033[0m\n' "$1" >&2; exit 1; }

command -v kubectl >/dev/null 2>&1 || die "kubectl not found."
kubectl get ns "$NS" >/dev/null 2>&1 || die "namespace '$NS' not found — run ./scripts/fresh-start.sh first."

# Verify metrics-server is serving metrics; the HPA is useless without it.
if ! kubectl top pods -n "$NS" >/dev/null 2>&1; then
  die "metrics-server isn't ready (kubectl top pods failed).
     Re-run ./scripts/fresh-start.sh so metrics-server gets installed, then retry."
fi

show_state() {
  say "HPA state"
  kubectl get hpa -n "$NS"
  say "Pods (replicas per service)"
  kubectl get pods -n "$NS" -o wide | awk '{print $1"\t"$3}'
  say "Live CPU usage"
  kubectl top pods -n "$NS" 2>/dev/null || true
}

# A portable "watch": the real `watch` command doesn't exist in Git Bash on
# Windows, so fall back to a clear-and-print loop that works everywhere.
watch_hpa() {
  if command -v watch >/dev/null 2>&1; then
    watch -n 2 "kubectl get hpa -n $NS; echo; kubectl get pods -n $NS | grep -E 'frontend|catalog'"
  else
    while true; do
      clear 2>/dev/null || printf '\033[2J\033[H'
      kubectl get hpa -n "$NS"
      echo
      kubectl get pods -n "$NS" | grep -E 'NAME|frontend|catalog'
      sleep 2
    done
  fi
}

if [[ $WATCH_ONLY -eq 1 ]]; then
  say "Watching the HPA (Ctrl-C to stop). Run some traffic in another window."
  watch_hpa
  exit 0
fi

say "BEFORE — everything idle, sitting at the minimum replica count"
show_state
info ""
info "Watch the autoscaler live in a SECOND terminal with:"
info "    ./scripts/autoscale-demo.sh --watch      (works on Windows Git Bash too)"
info ""

# ---- generate load --------------------------------------------------------
say "Generating traffic against $BASE for ${LOAD_SECONDS}s"
info "As CPU crosses the target (70%), the HPA adds pods automatically."

if command -v k6 >/dev/null 2>&1; then
  info "using k6 (loadtest/k6/flash_sale.js)"
  # A shorter, self-contained ramp so the demo fits in a couple of minutes.
  BASE_URL="$BASE" k6 run --quiet \
    --stage "20s:200" --stage "${LOAD_SECONDS}s:200" --stage "10s:0" \
    loadtest/k6/checkout.js || true
else
  info "k6 not found — using a portable curl-based load generator"
  command -v curl >/dev/null 2>&1 || die "need either k6 or curl to generate load."
  WORKERS=40
  pids=()
  end=$(( $(date +%s) + LOAD_SECONDS ))
  for _ in $(seq 1 "$WORKERS"); do
    (
      while [[ $(date +%s) -lt $end ]]; do
        curl -s -o /dev/null "$BASE/api/products" || true
        curl -s -o /dev/null -X POST "$BASE/api/orders" \
          -H 'content-type: application/json' \
          -d '{"userId":"load","items":[{"productId":"p-001","quantity":1}],"total":19.99}' || true
      done
    ) &
    pids+=($!)
  done
  info "$WORKERS concurrent workers hammering the storefront..."
  # Report HPA state every ~15s while the load runs.
  while [[ $(date +%s) -lt $end ]]; do
    sleep 15
    printf '\n\033[1;33m--- %ss of load: ---\033[0m\n' "$(( LOAD_SECONDS - (end - $(date +%s)) ))"
    kubectl get hpa -n "$NS" 2>/dev/null || true
  done
  wait "${pids[@]}" 2>/dev/null || true
fi

say "PEAK — under load: CPU is high and the HPA has scaled pods UP"
show_state

# ---- cool down ------------------------------------------------------------
say "Traffic stopped. The HPA scales back DOWN after a stabilization window"
info "Kubernetes waits ~5 min (scale-down stabilization) before removing pods,"
info "so replicas stay high for a bit, then shrink to the minimum on their own."
info ""
info "Watch it come back down with:"
info "    ./scripts/autoscale-demo.sh --watch"

cat <<EOF

$(printf '\033[1;32m✔ Autoscaling demo complete.\033[0m')

  What you just saw — automatic, load-based scaling with NO manual step:
    idle   -> HPA holds pods at minReplicas (2)
    load   -> CPU crosses 70% target -> HPA adds pods (up to maxReplicas 10)
    quiet  -> after the stabilization window, HPA removes pods back to 2

  Inspect it:   kubectl describe hpa frontend -n $NS
  Tunables:     helm/ecommerce/values.yaml  (autoscaling.* per service)
EOF
